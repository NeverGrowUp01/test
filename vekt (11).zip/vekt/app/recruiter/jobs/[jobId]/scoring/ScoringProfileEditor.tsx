"use client";

import { useMemo, useState } from "react";

type Criterion = {
  id: string;
  label: string;
  weight: number;
};

export default function ScoringProfileEditor({
  jobId,
  jobTitle,
  initialProfile,
}: {
  jobId: string;
  jobTitle: string;
  initialProfile: Criterion[];
}) {
  const [profile, setProfile] = useState<Criterion[]>(initialProfile);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const total = useMemo(
    () => profile.reduce((sum, item) => sum + Number(item.weight || 0), 0),
    [profile],
  );

  function updateCriterion(
    index: number,
    field: "label" | "weight",
    value: string,
  ) {
    setProfile((current) =>
      current.map((item, i) =>
        i === index
          ? {
              ...item,
              [field]:
                field === "weight" ? Number(value) : value,
            }
          : item,
      ),
    );
  }

  function addCriterion() {
    setProfile((current) => [
      ...current,
      {
        id: `criterion_${Date.now()}`,
        label: "New criterion",
        weight: 0,
      },
    ]);
  }

  function removeCriterion(index: number) {
    setProfile((current) =>
      current.filter((_, i) => i !== index),
    );
  }

  async function save() {
    setMessage("");

    if (profile.length === 0) {
      setMessage("Add at least one criterion.");
      return;
    }

    if (Math.abs(total - 100) > 0.001) {
      setMessage(`Weights must total 100%. Current total: ${total}%.`);
      return;
    }

    for (const criterion of profile) {
      if (!criterion.label.trim()) {
        setMessage("Every criterion needs a name.");
        return;
      }

      if (
        !Number.isFinite(criterion.weight) ||
        criterion.weight < 0 ||
        criterion.weight > 100
      ) {
        setMessage(`Invalid weight for "${criterion.label}".`);
        return;
      }
    }

    setSaving(true);

    try {
      const response = await fetch(
        `/api/recruiter/jobs/${jobId}/scoring-profile`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ profile }),
        },
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ?? "Failed to save scoring profile.",
        );
      }

      setProfile(data.profile);
      setMessage("Scoring profile saved.");
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Failed to save scoring profile.",
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-4xl p-6">
      <div className="mb-6">
        <p className="text-sm text-muted-foreground">Job</p>

        <h1 className="text-2xl font-semibold">
          {jobTitle}
        </h1>

        <p className="mt-2 text-sm text-muted-foreground">
          Configure how Vekt evaluates candidates for this job.
          The AI scores each criterion, and Vekt calculates the
          final weighted score.
        </p>
      </div>

      <div className="rounded-xl border bg-card">
        <div className="border-b p-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="font-semibold">
                Scoring criteria
              </h2>

              <p className="text-sm text-muted-foreground">
                All weights must add up to exactly 100%.
              </p>
            </div>

            <div
              className={
                Math.abs(total - 100) < 0.001
                  ? "text-sm font-semibold text-green-600"
                  : "text-sm font-semibold text-destructive"
              }
            >
              Total: {total}%
            </div>
          </div>
        </div>

        <div className="divide-y">
          {profile.map((criterion, index) => (
            <div
              key={criterion.id}
              className="grid gap-3 p-4 md:grid-cols-[1fr_120px_auto] md:items-end"
            >
              <div>
                <label className="mb-1 block text-sm font-medium">
                  Criterion
                </label>

                <input
                  value={criterion.label}
                  onChange={(event) =>
                    updateCriterion(
                      index,
                      "label",
                      event.target.value,
                    )
                  }
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium">
                  Weight %
                </label>

                <input
                  type="number"
                  min={0}
                  max={100}
                  step={1}
                  value={criterion.weight}
                  onChange={(event) =>
                    updateCriterion(
                      index,
                      "weight",
                      event.target.value,
                    )
                  }
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                />
              </div>

              <button
                type="button"
                onClick={() => removeCriterion(index)}
                className="rounded-md border px-3 py-2 text-sm text-destructive hover:bg-destructive/10"
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-3 border-t p-4 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            onClick={addCriterion}
            className="rounded-md border px-4 py-2 text-sm font-medium hover:bg-muted"
          >
            Add criterion
          </button>

          <button
            type="button"
            onClick={save}
            disabled={
              saving || Math.abs(total - 100) > 0.001
            }
            className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            {saving ? "Saving..." : "Save scoring profile"}
          </button>
        </div>

        {message && (
          <div className="border-t p-4 text-sm">
            {message}
          </div>
        )}
      </div>

      <div className="mt-6 rounded-xl border p-4">
        <h3 className="font-medium">
          How scoring works
        </h3>

        <p className="mt-2 text-sm text-muted-foreground">
          Qwen evaluates each criterion from the resume evidence.
          Vekt then applies these weights mathematically to produce
          the final score. The recruiter still makes the hiring
          decision manually.
        </p>
      </div>
    </main>
  );
}