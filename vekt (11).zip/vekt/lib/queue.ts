import { CandidateStatus, EmailType } from "@/generated/client";
import { evaluateCandidate } from "@/lib/ai";
import { sendCandidateEmail } from "@/lib/email";
import { inngest } from "@/lib/inngest";
import logger from "@/lib/logger";
import { prisma } from "@/lib/prisma";
import fs from "fs/promises";
import path from "path";

/**
 * Durable AI evaluation pipeline.
 *
 * IMPORTANT:
 * AI evaluation never sends a candidate email.
 *
 * The recruiter must manually choose:
 *   SHORTLIST
 *   REJECT
 *   ACCEPT
 *
 * before a candidate-facing status email is sent.
 */
export const analyzeCandidate = inngest.createFunction(
  {
    id: "analyze-candidate",
    retries: 5,
  },
  { event: "vekt/candidate.created" },
  async ({ event, step }) => {
    const { candidateId } = event.data as {
      candidateId: string;
    };

    await step.run("log-pipeline-start", async () => {
      logger.info(
        { candidateId },
        "Pipeline: analyzeCandidate started",
      );
    });

    /*
     * DO NOT send APPLIED email here.
     *
     * Candidate-facing email is intentionally controlled by
     * recruiter status decisions only.
     */

    await step.run("mark-analyzing", async () => {
      try {
        await prisma.candidate.update({
          where: { id: candidateId },
          data: {
            status: CandidateStatus.ANALYZING,
          },
        });
      } catch (error) {
        logger.error(
          {
            candidateId,
            step: "mark-analyzing",
            error,
          },
          "Pipeline: step failed",
        );

        throw error;
      }
    });

    const candidate = await step.run(
      "fetch-candidate",
      async () => {
        try {
          return await prisma.candidate.findUniqueOrThrow({
            where: {
              id: candidateId,
            },
            include: {
              job: true,
            },
          });
        } catch (error) {
          logger.error(
            {
              candidateId,
              step: "fetch-candidate",
              error,
            },
            "Pipeline: step failed",
          );

          throw error;
        }
      },
    );

    const evaluated = await step.run(
      "ai-evaluate",
      async () => {
        try {
          const job = candidate.job;

          const {
            result,
            promptSnapshot,
            provenance,
          } = await evaluateCandidate({
            jobTitle:
              job?.title ?? "General Position",
            jobDescription:
              job?.description ?? "",
            customPrompt:
              job?.customPrompt ?? null,
            resumeText: candidate.resumeText,
            candidateName: candidate.name,
          });

          return {
            result,
            promptSnapshot,
            provenance,
          };
        } catch (error) {
          logger.error(
            {
              candidateId,
              step: "ai-evaluate",
              error,
            },
            "Pipeline: step failed",
          );

          throw error;
        }
      },
    );

    /*
     * Always leave the candidate for human review after AI evaluation.
     *
     * The AI score is still stored and visible to the recruiter.
     * The AI does NOT make the final candidate status decision.
     */
    await step.run("save-evaluation", async () => {
      try {
        const {
          result,
          promptSnapshot,
          provenance,
        } = evaluated;

        await prisma.$transaction([
          prisma.evaluation.create({
            data: {
              candidateId,
              score: result.score,
              reasoning: result.reasoning,
              pros: JSON.stringify(result.pros),
              cons: JSON.stringify(result.cons),
              promptSnapshot,
              provider: provenance.provider,
              model: provenance.model,
              promptHash: provenance.promptHash,
              evaluatorVersion:
                provenance.evaluatorVersion,
              redactions:
                JSON.stringify(provenance.redactions),
              autoDecision: false,
            },
          }),

          prisma.candidate.update({
            where: {
              id: candidateId,
            },
            data: {
              status: CandidateStatus.NEEDS_REVIEW,
            },
          }),
        ]);
      } catch (error) {
        logger.error(
          {
            candidateId,
            step: "save-evaluation",
            error,
          },
          "Pipeline: step failed",
        );

        throw error;
      }
    });

    await step.run("log-pipeline-complete", async () => {
      logger.info(
        {
          candidateId,
          score: evaluated.result.score,
          provider: evaluated.provenance.provider,
          model: evaluated.provenance.model,
          promptHash: evaluated.provenance.promptHash,
          evaluatorVersion: evaluated.provenance.evaluatorVersion,
          autoDecision: false,
          awaitingHumanReview: true,
        },
        "Pipeline: analyzeCandidate completed",
      );
    });

    return {
      candidateId,
      score: evaluated.result.score,
      status: CandidateStatus.NEEDS_REVIEW,
    };
  },
);

/**
 * Daily retention cleanup.
 *
 * This is unrelated to recruitment decisions.
 * It preserves the existing retention-warning behavior and
 * removes candidates/resumes after the configured retention period.
 */
export const purgeExpiredCandidates =
  inngest.createFunction(
    {
      id: "purge-expired-candidates",
      retries: 2,
    },
    {
      cron: "0 2 * * *",
    },
    async ({ step }) => {
      const setting = await step.run(
        "read-retention-setting",
        async () => {
          return prisma.setting.findUnique({
            where: {
              key: "RETENTION_DAYS",
            },
          });
        },
      );

      const retentionDays = setting
        ? parseInt(setting.value, 10)
        : 90;

      if (
        Number.isNaN(retentionDays) ||
        retentionDays <= 0
      ) {
        logger.warn(
          {
            retentionDays: setting?.value,
          },
          "Purge: invalid RETENTION_DAYS, skipping",
        );

        return {
          deleted: 0,
          warned: 0,
        };
      }

      const cutoff = new Date();

      cutoff.setDate(
        cutoff.getDate() - retentionDays,
      );

      const expired = await step.run(
        "fetch-expired-candidates",
        async () => {
          return prisma.candidate.findMany({
            where: {
              appliedAt: {
                lt: cutoff,
              },
            },
            select: {
              id: true,
              resumePath: true,
            },
          });
        },
      );

      /*
       * Send retention warnings for candidates that
       * are within seven days of expiration.
       */
      let warned = 0;

      if (retentionDays >= 7) {
        warned = await step.run(
          "send-retention-warnings",
          async () => {
            const warnCutoff = new Date();

            warnCutoff.setDate(
              warnCutoff.getDate() -
                (retentionDays - 7),
            );

            const aboutToExpire =
              await prisma.candidate.findMany({
                where: {
                  appliedAt: {
                    gte: cutoff,
                    lt: warnCutoff,
                  },
                },
                select: {
                  id: true,
                  emailLogs: {
                    where: {
                      type:
                        EmailType.DATA_RETENTION_WARNING,
                    },
                    select: {
                      id: true,
                    },
                  },
                },
              });

            let count = 0;

            for (const candidate of aboutToExpire) {
              if (candidate.emailLogs.length > 0) {
                continue;
              }

              try {
                await sendCandidateEmail({
                  candidateId: candidate.id,
                  type:
                    EmailType.DATA_RETENTION_WARNING,
                });

                count++;
              } catch (error) {
                logger.warn(
                  {
                    candidateId: candidate.id,
                    error,
                  },
                  "Purge: retention warning email failed",
                );
              }
            }

            logger.info(
              {
                warned: count,
                total: aboutToExpire.length,
              },
              "Purge: sent retention warnings",
            );

            return count;
          },
        );
      }

      if (expired.length === 0) {
        logger.info(
          {
            retentionDays,
            cutoff,
            warned,
          },
          "Purge: no expired candidates",
        );

        return {
          deleted: 0,
          warned,
        };
      }

      await step.run(
        "delete-resume-files",
        async () => {
          const uploadsDir = path.join(
            process.cwd(),
            "private",
            "uploads",
          );

          for (const candidate of expired) {
            const filename = path.basename(
              candidate.resumePath,
            );

            /*
             * Only delete UUID filenames.
             * This protects against accidentally deleting
             * arbitrary filesystem paths.
             */
            if (
              /^[a-f0-9-]{36}\.pdf$/i.test(
                filename,
              )
            ) {
              await fs
                .unlink(
                  path.join(
                    uploadsDir,
                    filename,
                  ),
                )
                .catch(() => {
                  // Already deleted; nothing to do.
                });
            }
          }
        },
      );

      const { count } = await step.run(
        "delete-candidate-records",
        async () => {
          return prisma.candidate.deleteMany({
            where: {
              id: {
                in: expired.map(
                  (candidate) => candidate.id,
                ),
              },
            },
          });
        },
      );

      logger.info(
        {
          deleted: count,
          warned,
          retentionDays,
          cutoff,
        },
        "Purge: completed",
      );

      return {
        deleted: count,
        warned,
      };
    },
  );

/**
 * Direct evaluation fallback.
 *
 * Used when Inngest is not configured.
 *
 * IMPORTANT:
 * This performs exactly the same human-review behavior
 * as the durable Inngest pipeline.
 */
export async function runEvaluationPipelineDirect(
  candidateId: string,
): Promise<void> {
  logger.info(
    { candidateId },
    "Pipeline: starting direct evaluation",
  );

  try {
    await prisma.candidate.update({
      where: { id: candidateId },
      data: { status: CandidateStatus.ANALYZING },
    });

    const candidate = await prisma.candidate.findUniqueOrThrow({
      where: { id: candidateId },
      include: { job: true },
    });

    const { result, promptSnapshot, provenance } =
      await evaluateCandidate({
        jobTitle: candidate.job?.title ?? "General Position",
        jobDescription: candidate.job?.description ?? "",
        customPrompt: candidate.job?.customPrompt ?? null,
        scoringProfile: candidate.job?.scoringProfile ?? null,
        resumeText: candidate.resumeText,
        candidateName: candidate.name,
      });

    await prisma.$transaction([
      prisma.evaluation.create({
        data: {
          candidateId,
          score: result.score,
          criteriaScores: JSON.stringify(result.criteria),
          reasoning: result.reasoning,
          pros: JSON.stringify(result.pros),
          cons: JSON.stringify(result.cons),
          promptSnapshot,
          provider: provenance.provider,
          model: provenance.model,
          promptHash: provenance.promptHash,
          evaluatorVersion: provenance.evaluatorVersion,
          redactions: JSON.stringify(provenance.redactions),
          autoDecision: false,
        },
      }),
      prisma.candidate.update({
        where: { id: candidateId },
        data: { status: CandidateStatus.NEEDS_REVIEW },
      }),
    ]);

    logger.info(
      {
        candidateId,
        score: result.score,
        provider: provenance.provider,
        model: provenance.model,
        promptHash: provenance.promptHash,
        evaluatorVersion: provenance.evaluatorVersion,
        autoDecision: false,
        awaitingHumanReview: true,
      },
      "Pipeline: direct evaluation complete",
    );
  } catch (error) {
    logger.error(
      { candidateId, error },
      "Pipeline: direct evaluation failed",
    );
    throw error;
  }
}
