import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { parseScoringProfile } from "@/lib/scoring";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const session = await auth();

  if (!session) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 },
    );
  }

  const isAdmin =
    (session.user as { role?: string }).role === "ADMIN";

  const currentUserId = session.user?.id;

  if (!isAdmin && !currentUserId) {
    return NextResponse.json(
      { error: "Session is stale. Please sign in again." },
      { status: 401 },
    );
  }

  const { jobId } = await params;

  const job = await prisma.job.findFirst({
    where: {
      id: jobId,
      ...(!isAdmin && currentUserId
        ? { createdById: currentUserId }
        : {}),
    },
    select: {
      id: true,
      title: true,
      scoringProfile: true,
    },
  });

  if (!job) {
    return NextResponse.json(
      { error: "Job not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({
    jobId: job.id,
    title: job.title,
    profile: parseScoringProfile(job.scoringProfile),
  });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const session = await auth();

  if (!session) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 },
    );
  }

  const isAdmin =
    (session.user as { role?: string }).role === "ADMIN";

  const currentUserId = session.user?.id;

  if (!isAdmin && !currentUserId) {
    return NextResponse.json(
      { error: "Session is stale. Please sign in again." },
      { status: 401 },
    );
  }

  const { jobId } = await params;

  const job = await prisma.job.findFirst({
    where: {
      id: jobId,
      ...(!isAdmin && currentUserId
        ? { createdById: currentUserId }
        : {}),
    },
    select: {
      id: true,
    },
  });

  if (!job) {
    return NextResponse.json(
      { error: "Job not found" },
      { status: 404 },
    );
  }

  const body = await req.json();
  const profile = body?.profile;

  if (!Array.isArray(profile) || profile.length === 0) {
    return NextResponse.json(
      { error: "Profile must contain at least one criterion." },
      { status: 400 },
    );
  }

  const ids = new Set<string>();
  let total = 0;

  for (const criterion of profile) {
    if (
      !criterion ||
      typeof criterion.id !== "string" ||
      typeof criterion.label !== "string" ||
      typeof criterion.weight !== "number"
    ) {
      return NextResponse.json(
        { error: "Invalid scoring criterion." },
        { status: 400 },
      );
    }

    if (ids.has(criterion.id)) {
      return NextResponse.json(
        { error: `Duplicate criterion ID: ${criterion.id}` },
        { status: 400 },
      );
    }

    ids.add(criterion.id);

    if (!criterion.label.trim()) {
      return NextResponse.json(
        { error: "Every criterion needs a label." },
        { status: 400 },
      );
    }

    if (
      !Number.isFinite(criterion.weight) ||
      criterion.weight < 0 ||
      criterion.weight > 100
    ) {
      return NextResponse.json(
        {
          error: `Invalid weight for "${criterion.label}".`,
        },
        { status: 400 },
      );
    }

    total += criterion.weight;
  }

  if (Math.abs(total - 100) > 0.001) {
    return NextResponse.json(
      {
        error: `Weights must total 100%. Current total: ${total}%.`,
      },
      { status: 400 },
    );
  }

  const normalizedProfile = profile.map((criterion) => ({
    id: criterion.id.trim(),
    label: criterion.label.trim(),
    weight: Math.round(criterion.weight * 100) / 100,
  }));

  await prisma.job.update({
    where: { id: jobId },
    data: {
      scoringProfile: JSON.stringify(normalizedProfile),
    },
  });

  return NextResponse.json({
    profile: normalizedProfile,
  });
}