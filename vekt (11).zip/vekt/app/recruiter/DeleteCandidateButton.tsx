"use client";

import { useState } from "react";

export default function DeleteCandidateButton({
  candidateId,
}: {
  candidateId: string;
}) {
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    const confirmed = window.confirm(
      "Delete this candidate permanently?\n\n" +
        "This will delete the candidate record, resume file, AI evaluation, " +
        "criterion scores/evidence, answers, and email logs.\n\n" +
        "This cannot be undone.",
    );

    if (!confirmed) return;

    setDeleting(true);

    try {
      const response = await fetch(
        `/api/recruiter/candidates/${candidateId}`,
        {
          method: "DELETE",
        },
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.error ?? "Failed to delete candidate.",
        );
      }

      window.location.reload();
    } catch (error) {
      window.alert(
        error instanceof Error
          ? error.message
          : "Failed to delete candidate.",
      );
      setDeleting(false);
    }
  }

  return (
    <button
      type="button"
      onClick={handleDelete}
      disabled={deleting}
      className="inline-flex items-center rounded-md border border-destructive/40 px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 disabled:opacity-50"
    >
      {deleting ? "Deleting..." : "Delete"}
    </button>
  );
}