# Vekt recruitment features - one-time modification script
# Run this from: C:\Vekt\vekt
# Prerequisite: your working Vekt backup already exists.

$ErrorActionPreference = "Stop"

if (-not (Test-Path "schema\schema.prisma")) {
    throw "Run this script from C:\Vekt\vekt"
}

Write-Host "== Vekt feature update ==" -ForegroundColor Cyan

# 1) Install the two small dependencies needed for XLSX export and SMTP email.
Write-Host "Installing XLSX + SMTP dependencies..." -ForegroundColor Yellow
pnpm add xlsx nodemailer
pnpm add -D @types/nodemailer

# 2) Prisma schema: source tracking + fix enum-default syntax.
$schemaPath = "schema\schema.prisma"
$schema = Get-Content -Raw -LiteralPath $schemaPath

$schema = $schema.Replace('@default("SINGLE")', '@default(SINGLE)')
$schema = $schema.Replace('@default("APPLIED")', '@default(APPLIED)')

$newCandidate = @'
model Candidate {
  id                   String            @id @default(cuid())
  name                 String
  email                String
  resumePath           String
  resumeText           String            @default("")
  source               CandidateSource   @default(WEBSITE)
  status               CandidateStatus   @default(APPLIED)
  appliedAt            DateTime          @default(now())
  updatedAt            DateTime          @updatedAt
  jobId                String?
  consentGiven         Boolean           @default(false)
  consentAt            DateTime?
  privacyPolicyVersion String?
  emailOptOut          Boolean           @default(false)
  job                  Job?              @relation(fields: [jobId], references: [id])
  answers              CandidateAnswer[]
  emailLogs            EmailLog[]
  evaluation           Evaluation?
}
'@

$schema = [regex]::Replace($schema, '(?ms)^model Candidate \{.*?^\}', $newCandidate.TrimEnd())
if ($schema -notmatch '(?m)^model Candidate \{') {
    throw "Candidate model was not found. No schema changes were written."
}

$newEnum = @'
enum CandidateSource {
  WEBSITE
  EMAIL
  LINKEDIN
  PEOPLEHUM
  WHATSAPP
  REFERRAL
  JOB_PORTAL
  OTHER
}
'@

if ($schema -notmatch '(?m)^enum CandidateSource \{') {
    $schema = [regex]::Replace($schema, '(?ms)^enum CandidateStatus \{.*?^\}', '$0' + "`r`n" + $newEnum.TrimEnd(), 1)
}

Set-Content -LiteralPath $schemaPath -Value $schema -Encoding UTF8



# 3) Public application API: always mark website applications as WEBSITE.
$candidateApiPath = "app\api\candidates\route.ts"
$candidateApi = Get-Content -Raw -LiteralPath $candidateApiPath
$candidateApi = $candidateApi.Replace(
'import { auth } from "@/lib/auth";',
'import { CandidateSource } from "@/generated/client";' + "`r`n" + 'import { auth } from "@/lib/auth";'
)
$candidateApi = $candidateApi.Replace(
'        resumeText,' + "`r`n" + '        consentGiven: true,',
'        resumeText,' + "`r`n" + '        source: CandidateSource.WEBSITE,' + "`r`n" + '        consentGiven: true,'
)
$candidateApi = $candidateApi.Replace(
'       evaluation: { select: { score: true } },',
'       source: true,' + "`r`n" + '       evaluation: { select: { score: true } },'
)
Set-Content -LiteralPath $candidateApiPath -Value $candidateApi -Encoding UTF8

# 4) Bulk single-file endpoint. The UI will call this once per PDF, sequentially,
#    which gives reliable progress and keeps local Ollama memory usage low.
New-Item -ItemType Directory -Force -Path "app\api\recruiter\bulk-candidates" | Out-Null
$bulkRoute = @'
import { CandidateSource } from "@/generated/client";
import { auth } from "@/lib/auth";
import { PRIVACY_POLICY_VERSION } from "@/lib/brand";
import { runEvaluationPipelineDirect } from "@/lib/queue";
import { prisma } from "@/lib/prisma";
import logger from "@/lib/logger";
import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { extractText } from "unpdf";

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const UPLOADS_DIR = path.join(process.cwd(), "private", "uploads");

const SOURCES = new Set(Object.values(CandidateSource));

function guessEmail(text: string): string | null {
  const match = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return match?.[0]?.toLowerCase() ?? null;
}

function guessName(text: string, filename: string): string {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter(Boolean);

  const email = guessEmail(text);
  for (const line of lines.slice(0, 12)) {
    if (email && line.toLowerCase().includes(email.toLowerCase())) continue;
    if (line.length < 3 || line.length > 80) continue;
    if (/^(resume|curriculum vitae|cv|profile|contact|experience|education|skills)$/i.test(line)) continue;
    if (/^[^a-zA-Z]*$/.test(line)) continue;
    if (/\d{3,}/.test(line)) continue;
    return line;
  }

  const base = path.basename(filename, path.extname(filename))
    .replace(/[_-]+/g, " ")
    .replace(/\b(resume|cv)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();

  return base || "Unknown Candidate";
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const isAdmin = (session.user as { role?: string }).role === "ADMIN";
    const currentUserId = session.user?.id;
    if (!isAdmin && !currentUserId) {
      return NextResponse.json({ error: "Session is stale. Please sign in again." }, { status: 401 });
    }

    const form = await req.formData();
    const resume = form.get("resume");
    const jobId = String(form.get("jobId") ?? "");
    const source = String(form.get("source") ?? "OTHER") as CandidateSource;

    if (!(resume instanceof File) || resume.type !== "application/pdf") {
      return NextResponse.json({ error: "A PDF resume is required." }, { status: 400 });
    }
    if (resume.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: "Resume must be under 5 MB." }, { status: 413 });
    }
    if (!SOURCES.has(source)) {
      return NextResponse.json({ error: "Invalid candidate source." }, { status: 400 });
    }

    const job = await prisma.job.findFirst({
      where: {
        id: jobId,
        isActive: true,
        ...(!isAdmin && currentUserId ? { createdById: currentUserId } : {}),
      },
      select: { id: true, title: true },
    });
    if (!job) return NextResponse.json({ error: "Job not found or not accessible." }, { status: 404 });

    const bytes = await resume.arrayBuffer();
    let resumeText = "";
    try {
      const extracted = await extractText(new Uint8Array(bytes), { mergePages: true });
      resumeText = Array.isArray(extracted.text) ? extracted.text.join("\n") : (extracted.text ?? "");
    } catch (error) {
      logger.warn({ error }, "Bulk upload: PDF text extraction failed");
    }

    const email = guessEmail(resumeText);
    if (!email) {
      return NextResponse.json({
        error: "Could not find an email address in this resume. Upload this candidate manually.",
      }, { status: 422 });
    }

    const name = guessName(resumeText, resume.name);

    await mkdir(UPLOADS_DIR, { recursive: true });
    const filename = `${randomUUID()}.pdf`;
    await writeFile(path.join(UPLOADS_DIR, filename), Buffer.from(bytes));

    const candidate = await prisma.candidate.create({
      data: {
        name,
        email,
        resumePath: `/api/uploads/${filename}`,
        resumeText,
        source,
        consentGiven: false,
        privacyPolicyVersion: PRIVACY_POLICY_VERSION,
        jobId,
      },
      select: { id: true, name: true, email: true, status: true },
    });

    // Deliberately sequential: this is a local Ollama deployment on a laptop.
    await runEvaluationPipelineDirect(candidate.id);

    const finished = await prisma.candidate.findUnique({
      where: { id: candidate.id },
      select: {
        id: true,
        name: true,
        email: true,
        status: true,
        evaluation: { select: { score: true } },
      },
    });

    return NextResponse.json({
      ok: true,
      candidate: finished ?? candidate,
      filename: resume.name,
    }, { status: 201 });
  } catch (error) {
    logger.error({ error }, "API: bulk candidate upload failed");
    return NextResponse.json({ error: "Bulk candidate import failed." }, { status: 500 });
  }
}
'@
Set-Content -LiteralPath "app\api\recruiter\bulk-candidates\route.ts" -Value $bulkRoute -Encoding UTF8

# 5) Excel export endpoint.
New-Item -ItemType Directory -Force -Path "app\api\recruiter\export" | Out-Null
$exportRoute = @'
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import * as XLSX from "xlsx";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const isAdmin = (session.user as { role?: string }).role === "ADMIN";
  const currentUserId = session.user?.id;
  if (!isAdmin && !currentUserId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const candidates = await prisma.candidate.findMany({
    where: !isAdmin && currentUserId
      ? { job: { is: { createdById: currentUserId } } }
      : undefined,
    orderBy: { appliedAt: "desc" },
    include: {
      job: { select: { title: true } },
      evaluation: {
        select: {
          score: true,
          reasoning: true,
          pros: true,
          cons: true,
          provider: true,
          model: true,
          createdAt: true,
        },
      },
    },
  });

  const rows = candidates.map((c) => ({
    "Candidate Name": c.name,
    "Email": c.email,
    "Job": c.job?.title ?? "",
    "Source": c.source,
    "Application Date": c.appliedAt.toISOString(),
    "AI Score": c.evaluation?.score ?? "",
    "AI Summary": c.evaluation?.reasoning ?? "",
    "Pros": c.evaluation?.pros ?? "",
    "Cons": c.evaluation?.cons ?? "",
    "Candidate Status": c.status,
    "AI Provider": c.evaluation?.provider ?? "",
    "AI Model": c.evaluation?.model ?? "",
    "Evaluation Date": c.evaluation?.createdAt?.toISOString() ?? "",
    "Resume Filename": c.resumePath.split("/").pop() ?? "",
  }));

  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(workbook, worksheet, "Candidates");

  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="vekt-candidates-${new Date().toISOString().slice(0, 10)}.xlsx"`,
      "Cache-Control": "no-store",
    },
  });
}
'@
Set-Content -LiteralPath "app\api\recruiter\export\route.ts" -Value $exportRoute -Encoding UTF8

# 6) Bulk upload UI.
New-Item -ItemType Directory -Force -Path "app\recruiter\bulk-upload" | Out-Null
$bulkPage = @'
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import BulkUploadForm from "./BulkUploadForm";

export default async function BulkUploadPage() {
  const session = await auth();
  if (!session) redirect("/login");

  const isAdmin = (session.user as { role?: string }).role === "ADMIN";
  const currentUserId = session.user?.id;
  if (!isAdmin && !currentUserId) redirect("/login");

  const jobs = await prisma.job.findMany({
    where: {
      isActive: true,
      ...(!isAdmin && currentUserId ? { createdById: currentUserId } : {}),
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true },
  });

  return (
    <div className="min-h-[89vh] bg-background">
      <main className="mx-auto max-w-3xl p-6">
        <h1 className="text-lg font-semibold">Bulk Resume Upload</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Upload multiple PDFs into one job. Files are processed one at a time through your local AI.
        </p>
        <div className="mt-6">
          <BulkUploadForm jobs={jobs} />
        </div>
      </main>
    </div>
  );
}
'@
Set-Content -LiteralPath "app\recruiter\bulk-upload\page.tsx" -Value $bulkPage -Encoding UTF8

$bulkForm = @'
"use client";

import { useState } from "react";

type Job = { id: string; title: string };
type Source =
  | "EMAIL" | "LINKEDIN" | "PEOPLEHUM" | "WHATSAPP"
  | "REFERRAL" | "JOB_PORTAL" | "WEBSITE" | "OTHER";

const SOURCES: { value: Source; label: string }[] = [
  { value: "EMAIL", label: "Email" },
  { value: "LINKEDIN", label: "LinkedIn" },
  { value: "PEOPLEHUM", label: "PeopleHum" },
  { value: "WHATSAPP", label: "WhatsApp" },
  { value: "REFERRAL", label: "Referral" },
  { value: "JOB_PORTAL", label: "Job Portal" },
  { value: "WEBSITE", label: "Website" },
  { value: "OTHER", label: "Other" },
];

export default function BulkUploadForm({ jobs }: { jobs: Job[] }) {
  const [jobId, setJobId] = useState("");
  const [source, setSource] = useState<Source>("EMAIL");
  const [files, setFiles] = useState<File[]>([]);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{ file: string; ok: boolean; message: string }[]>([]);

  async function startUpload() {
    if (!jobId || files.length === 0 || running) return;
    setRunning(true);
    setResults([]);

    for (const file of files) {
      if (file.type !== "application/pdf") {
        setResults((r) => [...r, { file: file.name, ok: false, message: "PDF only" }]);
        continue;
      }

      try {
        const form = new FormData();
        form.append("resume", file);
        form.append("jobId", jobId);
        form.append("source", source);

        const response = await fetch("/api/recruiter/bulk-candidates", {
          method: "POST",
          body: form,
        });
        const data = await response.json();

        setResults((r) => [
          ...r,
          response.ok
            ? { file: file.name, ok: true, message: `Imported — AI score ${data.candidate?.evaluation?.score ?? "pending"}` }
            : { file: file.name, ok: false, message: data.error ?? "Import failed" },
        ]);
      } catch {
        setResults((r) => [...r, { file: file.name, ok: false, message: "Network error" }]);
      }
    }

    setRunning(false);
  }

  const done = results.length;
  const success = results.filter((r) => r.ok).length;

  return (
    <div className="rounded-xl border bg-card p-5 space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="text-sm font-medium">
          Job
          <select
            className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm"
            value={jobId}
            onChange={(e) => setJobId(e.target.value)}
            disabled={running}
          >
            <option value="">Select a job</option>
            {jobs.map((job) => <option key={job.id} value={job.id}>{job.title}</option>)}
          </select>
        </label>

        <label className="text-sm font-medium">
          Candidate source
          <select
            className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm"
            value={source}
            onChange={(e) => setSource(e.target.value as Source)}
            disabled={running}
          >
            {SOURCES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
          </select>
        </label>
      </div>

      <label className="block text-sm font-medium">
        Resume PDFs
        <input
          className="mt-1.5 block w-full rounded-md border bg-background px-3 py-2 text-sm"
          type="file"
          accept="application/pdf,.pdf"
          multiple
          onChange={(e) => {
            setFiles(Array.from(e.target.files ?? []));
            setResults([]);
          }}
          disabled={running}
        />
      </label>

      <div className="flex items-center justify-between gap-4">
        <p className="text-xs text-muted-foreground">
          {running ? `Processing ${done} / ${files.length}…` : `${files.length} file(s) selected${done ? ` · ${success} imported` : ""}`}
        </p>
        <button
          type="button"
          onClick={startUpload}
          disabled={running || !jobId || files.length === 0}
          className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
        >
          {running ? "Processing…" : "Start bulk upload"}
        </button>
      </div>

      {results.length > 0 && (
        <div className="space-y-2 border-t pt-4">
          {results.map((r, i) => (
            <div key={`${r.file}-${i}`} className="flex justify-between gap-4 rounded-md border px-3 py-2 text-sm">
              <span className="truncate">{r.file}</span>
              <span className={r.ok ? "text-green-600" : "text-destructive"}>{r.message}</span>
            </div>
          ))}
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        If a PDF does not contain a detectable email address, Vekt skips it so you can add that candidate manually.
        Bulk-imported candidates do not have consent asserted automatically.
      </p>
    </div>
  );
}
'@
Set-Content -LiteralPath "app\recruiter\bulk-upload\BulkUploadForm.tsx" -Value $bulkForm -Encoding UTF8

# 7) Candidate table: add source and local filters.
$tablePath = "app\recruiter\all\CandidatesTable.tsx"
$table = Get-Content -Raw -LiteralPath $tablePath
$table = $table.Replace(
'  status: string;' + "`r`n" + '  appliedAt: Date;',
'  status: string;' + "`r`n" + '  source: string;' + "`r`n" + '  appliedAt: Date;'
)
$table = $table.Replace(
'import { useState, useTransition } from "react";',
'import { useMemo, useState, useTransition } from "react";'
)
$table = $table.Replace(
'export default function CandidatesTable({ candidates }: { candidates: Candidate[] }) {' + "`r`n" + '  return (',
@'
export default function CandidatesTable({ candidates }: { candidates: Candidate[] }) {
  const [sourceFilter, setSourceFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [minScore, setMinScore] = useState("");
  const [fromDate, setFromDate] = useState("");

  const filtered = useMemo(() => candidates.filter((c) => {
    if (sourceFilter !== "ALL" && c.source !== sourceFilter) return false;
    if (statusFilter !== "ALL" && c.status !== statusFilter) return false;
    if (minScore && (c.evaluation?.score ?? -1) < Number(minScore)) return false;
    if (fromDate && new Date(c.appliedAt) < new Date(`${fromDate}T00:00:00`)) return false;
    return true;
  }), [candidates, sourceFilter, statusFilter, minScore, fromDate]);

  return (
'@
)
$table = $table.Replace(
'    <Table>' + "`r`n" + '      <TableHeader>',
@'
    <div className="mb-4 flex flex-wrap items-end gap-2">
      <select className="rounded-md border bg-background px-3 py-2 text-xs" value={sourceFilter} onChange={(e) => setSourceFilter(e.target.value)}>
        <option value="ALL">All sources</option>
        <option value="WEBSITE">Website</option><option value="EMAIL">Email</option>
        <option value="LINKEDIN">LinkedIn</option><option value="PEOPLEHUM">PeopleHum</option>
        <option value="WHATSAPP">WhatsApp</option><option value="REFERRAL">Referral</option>
        <option value="JOB_PORTAL">Job Portal</option><option value="OTHER">Other</option>
      </select>
      <select className="rounded-md border bg-background px-3 py-2 text-xs" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
        <option value="ALL">All statuses</option>
        <option value="APPLIED">Applied</option><option value="ANALYZING">Analyzing</option>
        <option value="SHORTLISTED">Shortlisted</option><option value="NEEDS_REVIEW">Needs review</option>
        <option value="ACCEPTED">Accepted</option><option value="REJECTED">Rejected</option>
      </select>
      <input className="w-28 rounded-md border bg-background px-3 py-2 text-xs" type="number" min="0" max="100" placeholder="Min score" value={minScore} onChange={(e) => setMinScore(e.target.value)} />
      <input className="rounded-md border bg-background px-3 py-2 text-xs" type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
    </div>
    <Table>
      <TableHeader>
'@
)
$table = $table.Replace(
'          <TableHead>Email</TableHead>' + "`r`n" + '          <TableHead>Status</TableHead>',
'          <TableHead>Email</TableHead>' + "`r`n" + '          <TableHead>Source</TableHead>' + "`r`n" + '          <TableHead>Status</TableHead>'
)
$table = $table.Replace(
'        {candidates.map((c) => (',
'        {filtered.map((c) => ('
)
$table = $table.Replace(
'            <TableCell>' + "`r`n" + '              <Badge',
'            <TableCell className="text-xs">{c.source.replace("_", " ")}</TableCell>' + "`r`n" + '            <TableCell>' + "`r`n" + '              <Badge'
)
$table = $table.Replace(
'{candidates.length === 0 && (',
'{filtered.length === 0 && ('
)
$table = $table.Replace(
'colSpan={7}',
'colSpan={8}'
)
Set-Content -LiteralPath $tablePath -Value $table -Encoding UTF8

# 8) All candidates page: add source to query + tools buttons.
$allPagePath = "app\recruiter\all\page.tsx"
$allPage = Get-Content -Raw -LiteralPath $allPagePath
$allPage = $allPage.Replace(
'        job: { select: { id: true, title: true } },',
'        job: { select: { id: true, title: true } },'
)
# Add source by putting it directly before evaluation.
$allPage = $allPage.Replace(
'      evaluation: {' + "`r`n" + '        select:',
'      source: true,' + "`r`n" + '      evaluation: {' + "`r`n" + '        select:'
)
$allPage = $allPage.Replace(
'import CandidatesTable from "./CandidatesTable";',
'import CandidatesTable from "./CandidatesTable";' + "`r`n" + 'import Link from "next/link";'
)
$allPage = $allPage.Replace(
'        <h1 className="text-lg font-semibold mb-4">All Candidates</h1>',
@'
        <div className="mb-4 flex items-center justify-between gap-3">
          <h1 className="text-lg font-semibold">All Candidates</h1>
          <div className="flex gap-2">
            <Link href="/recruiter/bulk-upload" className="rounded-md border px-3 py-2 text-xs font-medium hover:bg-muted">Bulk upload</Link>
            <a href="/api/recruiter/export" className="rounded-md bg-primary px-3 py-2 text-xs font-medium text-primary-foreground">Download Excel</a>
          </div>
        </div>
'@
)
Set-Content -LiteralPath $allPagePath -Value $allPage -Encoding UTF8

# 9) Job candidate page: show source.
$jobPagePath = "app\recruiter\jobs\[jobId]\page.tsx"
$jobPage = Get-Content -Raw -LiteralPath $jobPagePath
$jobPage = $jobPage.Replace(
'      evaluation: {' + "`r`n" + '        select: { score: true, reasoning: true, pros: true, cons: true },',
'      source: true,' + "`r`n" + '      evaluation: {' + "`r`n" + '        select: { score: true, reasoning: true, pros: true, cons: true },'
)
$jobPage = $jobPage.Replace(
'                <p className="text-xs text-muted-foreground">' + "`r`n" + '                  Applied{" "}',
'                <p className="text-xs text-muted-foreground">Source: {c.source.replace("_", " ")}</p>' + "`r`n" + '                <p className="text-xs text-muted-foreground">' + "`r`n" + '                  Applied{" "}'
)
Set-Content -LiteralPath $jobPagePath -Value $jobPage -Encoding UTF8

# 10) Replace email provider implementation with SMTP-first / Resend fallback.
$email = @'
import { EmailType } from "@/generated/client";
import { COMPANY_NAME } from "@/lib/brand";
import logger from "@/lib/logger";
import { prisma } from "@/lib/prisma";
import { createStatusToken, createUnsubscribeToken } from "@/lib/public-tokens";
import nodemailer from "nodemailer";
import { Resend } from "resend";

const APP_URL = process.env.APP_URL ?? "http://localhost:3000";
const FROM = process.env.EMAIL_FROM ?? "noreply@yourcompany.com";

function getSmtpTransport() {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const password = process.env.SMTP_PASSWORD;
  if (!host || !user || !password) return null;

  return nodemailer.createTransport({
    host,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: String(process.env.SMTP_SECURE ?? "false").toLowerCase() === "true",
    auth: { user, pass: password },
  });
}

function getResend() {
  const key = process.env.RESEND_API_KEY;
  if (!key) return null;
  return new Resend(key);
}

function interpolate(template: string, vars: Record<string, string>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] ?? `{{${key}}}`);
}

export function getStatusPageUrl(candidateId: string): string {
  return `${APP_URL}/status/${createStatusToken(candidateId)}`;
}

export function getUnsubscribeUrl(candidateId: string): string {
  return `${APP_URL}/api/unsubscribe?token=${createUnsubscribeToken(candidateId)}`;
}

interface SendEmailOptions {
  candidateId: string;
  type: EmailType;
}

export async function sendCandidateEmail({ candidateId, type }: SendEmailOptions): Promise<void> {
  const smtp = getSmtpTransport();
  const resend = getResend();

  if (!smtp && !resend) {
    logger.warn({ candidateId, type }, "Email: no SMTP or Resend configuration, skipping");
    return;
  }

  const candidate = await prisma.candidate.findUnique({
    where: { id: candidateId },
    include: { job: true },
  });

  if (!candidate) {
    logger.warn({ candidateId, type }, "Email: candidate not found, skipping");
    return;
  }

  if (candidate.emailOptOut && type !== EmailType.DATA_RETENTION_WARNING) {
    logger.info({ candidateId, type }, "Email: candidate opted out, skipping");
    return;
  }

  const template = await prisma.emailTemplate.findUnique({ where: { type } });
  if (!template) {
    logger.warn({ candidateId, type }, "Email: no template configured, skipping");
    return;
  }

  const retentionSetting = await prisma.setting.findUnique({ where: { key: "RETENTION_DAYS" } });
  const retentionDays = retentionSetting ? parseInt(retentionSetting.value, 10) : 90;
  const retentionDate = new Date(candidate.appliedAt);
  retentionDate.setDate(retentionDate.getDate() + retentionDays);

  const vars: Record<string, string> = {
    candidateName: candidate.name,
    jobTitle: candidate.job?.title ?? "General Position",
    companyName: COMPANY_NAME,
    statusPageUrl: getStatusPageUrl(candidateId),
    retentionDate: retentionDate.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }),
    applicationDate: candidate.appliedAt.toLocaleDateString("en-GB"),
    candidateStatus: candidate.status,
  };

  const subject = interpolate(template.subject, vars);
  const renderedBody = interpolate(template.body, vars);
  const unsubscribeFooter = `<p style="font-size:11px;color:#9ca3af;margin-top:24px;text-align:center;">
    You received this email because you applied for a position via ${COMPANY_NAME}.<br>
    <a href="${getUnsubscribeUrl(candidateId)}" style="color:#9ca3af;">Unsubscribe</a> from application updates.
  </p>`;
  const html = `${renderedBody}${unsubscribeFooter}`;

  try {
    let providerId: string | null = null;

    if (smtp) {
      const info = await smtp.sendMail({
        from: FROM,
        to: candidate.email,
        subject,
        html,
      });
      providerId = info.messageId ?? null;
    } else if (resend) {
      const { data, error } = await resend.emails.send({
        from: FROM,
        to: candidate.email,
        subject,
        html,
      });
      if (error) throw new Error(error.message);
      providerId = data?.id ?? null;
    }

    await prisma.emailLog.create({
      data: { candidateId, type, resendId: providerId },
    });

    logger.info({ candidateId, type, providerId }, "Email: sent");
  } catch (err) {
    logger.error({ candidateId, type, err }, "Email: send failed");
    throw err;
  }
}
'@
Set-Content -LiteralPath "lib\email.ts" -Value $email -Encoding UTF8

# 11) Environment template for private/company email.
$envExample = @'
DATABASE_URL="file:C:/Vekt/vekt/dev.db"
APP_URL="http://127.0.0.1:3000"
NEXTAUTH_URL="http://127.0.0.1:3000"
AUTH_TRUST_HOST="true"

AI_PROVIDER="ollama"
OLLAMA_BASE_URL="http://127.0.0.1:11434"
OLLAMA_MODEL="qwen2.5:3b-instruct"

INNGEST_EVENT_KEY=""
INNGEST_SIGNING_KEY=""

# Company email: SMTP is preferred for privacy.
SMTP_HOST=""
SMTP_PORT="587"
SMTP_SECURE="false"
SMTP_USER=""
SMTP_PASSWORD=""
EMAIL_FROM="recruitment@yourcompany.com"

# Optional legacy fallback:
RESEND_API_KEY=""

COMPANY_NAME="Your Company"
LOG_LEVEL="info"
'@
Set-Content -LiteralPath ".env.example" -Value $envExample -Encoding UTF8

# 12) Regenerate Prisma client and migrate the database.
Write-Host "Generating Prisma client..." -ForegroundColor Yellow
pnpm run db:generate

Write-Host "Applying database migration..." -ForegroundColor Yellow
pnpm run db:migrate

Write-Host ""
Write-Host "DONE." -ForegroundColor Green
Write-Host ""
Write-Host "Next:"
Write-Host "  1. Review .env and add SMTP values only when you are ready to enable email."
Write-Host "  2. Rebuild the standalone app:"
Write-Host '       pnpm run build'
Write-Host '       Copy-Item -Path ".next\static" -Destination ".next\standalone\.next\static" -Recurse -Force'
Write-Host '       Copy-Item -Path "public" -Destination ".next\standalone\public" -Recurse -Force'
Write-Host '       $env:DATABASE_URL="file:C:/Vekt/vekt/dev.db"'
Write-Host '       $env:HOSTNAME="127.0.0.1"'
Write-Host '       node .next/standalone/server.js'
Write-Host ""
Write-Host "Bulk upload: http://127.0.0.1:3000/recruiter/bulk-upload"
Write-Host "Candidates + Excel: http://127.0.0.1:3000/recruiter/all"
