import { extractText } from "unpdf";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { randomUUID } from "crypto";
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

type ExtractResult = {
  text: string;
  usedOcr: boolean;
};

function normalizeText(text: string): string {
  return text
    .replace(/\u0000/g, "")
    .replace(/\r/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function hasUsefulText(text: string): boolean {
  return normalizeText(text).length >= 40;
}

function findExecutable(
  explicit: string | undefined,
  windowsName: string,
  unixName: string,
): string {
  if (explicit) return explicit;
  return process.platform === "win32" ? windowsName : unixName;
}

async function runCommand(
  executable: string,
  args: string[],
): Promise<{ stdout: string; stderr: string }> {
  const result = await execFileAsync(executable, args, {
    windowsHide: true,
    maxBuffer: 20 * 1024 * 1024,
  });

  return {
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? "",
  };
}

async function extractPdfTextLayer(
  bytes: Uint8Array,
): Promise<string> {
  if (bytes.byteLength === 0) {
    return "";
  }

  try {
    const result = await extractText(bytes, {
      mergePages: true,
    });

    const text = Array.isArray(result.text)
      ? result.text.join("\n")
      : result.text ?? "";

    return normalizeText(text);
  } catch {
    return "";
  }
}

async function renderPdfPages(
  pdfPath: string,
  outputDirectory: string,
): Promise<string[]> {
  const pdfStats = await fs.stat(pdfPath);

  if (pdfStats.size === 0) {
    throw new Error(
      `PDF file is empty before OCR: ${pdfPath}`,
    );
  }

  const pdftoppm = findExecutable(
    process.env.PDFTOPPM_PATH,
    "pdftoppm.exe",
    "pdftoppm",
  );

  const prefix = path.join(
    outputDirectory,
    "resume-page",
  );

  await runCommand(pdftoppm, [
    "-png",
    "-r",
    "200",
    "-f",
    "1",
    "-l",
    "20",
    pdfPath,
    prefix,
  ]);

  const files = await fs.readdir(outputDirectory);

  return files
    .filter(
      (file) =>
        file.startsWith("resume-page-") &&
        file.toLowerCase().endsWith(".png"),
    )
    .sort((a, b) => {
      const pageA = Number(
        a.match(/-(\d+)\.png$/)?.[1] ?? 0,
      );

      const pageB = Number(
        b.match(/-(\d+)\.png$/)?.[1] ?? 0,
      );

      return pageA - pageB;
    })
    .map((file) =>
      path.join(outputDirectory, file),
    );
}

async function runTesseract(
  imagePath: string,
): Promise<string> {
  const tesseract = findExecutable(
    process.env.TESSERACT_PATH,
    "tesseract.exe",
    "tesseract",
  );

  const { stdout } = await runCommand(
    tesseract,
    [
      imagePath,
      "stdout",
      "-l",
      "eng",
      "--psm",
      "6",
    ],
  );

  return normalizeText(stdout);
}

async function extractFromPdfPath(
  pdfPath: string,
): Promise<string> {
  const tempDirectory = await fs.mkdtemp(
    path.join(
      os.tmpdir(),
      `vekt-ocr-${randomUUID()}-`,
    ),
  );

  try {
    const pages = await renderPdfPages(
      pdfPath,
      tempDirectory,
    );

    if (pages.length === 0) {
      throw new Error(
        "Poppler produced no page images.",
      );
    }

    const extractedPages: string[] = [];

    for (let index = 0; index < pages.length; index += 1) {
      const text = await runTesseract(pages[index]);

      if (text) {
        extractedPages.push(
          `--- Page ${index + 1} ---\n${text}`,
        );
      }
    }

    return normalizeText(
      extractedPages.join("\n\n"),
    );
  } finally {
    await fs.rm(tempDirectory, {
      recursive: true,
      force: true,
    });
  }
}

export async function extractResumeText(
  bytes: Uint8Array,
): Promise<ExtractResult> {
  if (bytes.byteLength === 0) {
    throw new Error(
      "Resume buffer is empty before PDF extraction.",
    );
  }

  const textLayer =
    await extractPdfTextLayer(bytes);

  if (hasUsefulText(textLayer)) {
    return {
      text: textLayer,
      usedOcr: false,
    };
  }

  const tempDirectory = await fs.mkdtemp(
    path.join(
      os.tmpdir(),
      `vekt-ocr-${randomUUID()}-`,
    ),
  );

  const pdfPath = path.join(
    tempDirectory,
    "resume.pdf",
  );

  try {
    await fs.writeFile(
      pdfPath,
      Buffer.from(bytes),
    );

    return {
      text: await extractFromPdfPath(pdfPath),
      usedOcr: true,
    };
  } finally {
    await fs.rm(tempDirectory, {
      recursive: true,
      force: true,
    });
  }
}

export async function extractResumeTextFromFile(
  pdfPath: string,
): Promise<ExtractResult> {
  const stats = await fs.stat(pdfPath);

  if (stats.size === 0) {
    throw new Error(
      `Saved resume PDF is empty: ${pdfPath}`,
    );
  }

  const bytes = new Uint8Array(
    await fs.readFile(pdfPath),
  );

  const textLayer =
    await extractPdfTextLayer(bytes);

  if (hasUsefulText(textLayer)) {
    return {
      text: textLayer,
      usedOcr: false,
    };
  }

  return {
    text: await extractFromPdfPath(pdfPath),
    usedOcr: true,
  };
}
