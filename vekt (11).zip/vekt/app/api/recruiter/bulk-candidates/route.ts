import { CandidateSource, CandidateStatus } from "@/generated/client";
import { auth } from "@/lib/auth";
import { PRIVACY_POLICY_VERSION } from "@/lib/brand";
import logger from "@/lib/logger";
import { prisma } from "@/lib/prisma";
import { runEvaluationPipelineDirect } from "@/lib/queue";
import {
  extractResumeTextFromFile,
} from "@/lib/resume-text";
import { randomUUID } from "crypto";
import {
  mkdir,
  stat,
  unlink,
  writeFile,
} from "fs/promises";
import path from "path";
import {
  NextRequest,
  NextResponse,
} from "next/server";

export const runtime = "nodejs";

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const MAX_FILES = 50;
const CONCURRENCY = 2;

const UPLOADS_DIR = path.join(
  process.cwd(),
  "private",
  "uploads",
);

const VALID_SOURCES = new Set<string>([
  "WEBSITE",
  "EMAIL",
  "LINKEDIN",
  "PEOPLEHUM",
  "WHATSAPP",
  "REFERRAL",
  "JOB_PORTAL",
  "OTHER",
]);

type BulkResult = {
  filename: string;
  success: boolean;
  candidateId?: string;
  name?: string;
  email?: string;
  error?: string;
};

function getFirstString(
  value: FormDataEntryValue | null,
): string {
  return typeof value === "string"
    ? value.trim()
    : "";
}

function normalizeEmail(
  value: string,
): string {
  return value
    .trim()
    .toLowerCase();
}

function extractEmailFromText(
  text: string,
): string {
  const match = text.match(
    /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,
  );

  return match?.[0]
    ? normalizeEmail(match[0])
    : "";
}

function cleanCandidateName(
  value: string,
): string {
  return value
    .replace(/\s+/g, " ")
    .replace(
      /^(name|curriculum vitae|resume|cv)\s*[:\-]?\s*/i,
      "",
    )
    .trim();
}

function extractNameFromText(
  text: string,
  filename: string,
): string {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const email = extractEmailFromText(text);

  for (const line of lines.slice(0, 15)) {
    const cleaned = cleanCandidateName(line);

    if (!cleaned) continue;
    if (cleaned.includes("@")) continue;

    if (
      /linkedin|github|http:\/\/|https:\/\/|www\./i.test(
        cleaned,
      )
    ) {
      continue;
    }

    if (
      /\+?\d[\d\s().-]{7,}/.test(cleaned)
    ) {
      continue;
    }

    if (
      /^(contact|profile|summary|experience|education|skills|projects|objective|about|phone|email|address)$/i.test(
        cleaned,
      )
    ) {
      continue;
    }

    const words = cleaned
      .split(/\s+/)
      .filter(Boolean);

    if (
      words.length >= 2 &&
      words.length <= 6 &&
      words.every((word) =>
        /^[A-Za-zÀ-ÿ.'-]+$/.test(word),
      )
    ) {
      return cleaned;
    }
  }

  const withoutExtension = filename
    .replace(/\.pdf$/i, "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const nameFromFilename = withoutExtension
    .replace(
      /\b(resume|cv|application|candidate)\b/gi,
      "",
    )
    .replace(
      /\b(accenture|citi|ellume)\b/gi,
      "",
    )
    .replace(/\s+/g, " ")
    .trim();

  if (nameFromFilename) {
    return nameFromFilename;
  }

  return email
    ? email.split("@")[0]
    : "Unknown Candidate";
}

function getFiles(
  formData: FormData,
): File[] {
  const entries = [
    ...formData.getAll("files"),
    ...formData.getAll("resumes"),
    ...formData.getAll("resume"),
  ];

  const files: File[] = [];

  for (const entry of entries) {
    if (entry instanceof File) {
      files.push(entry);
    }
  }

  return files;
}

async function processOneFile(
  file: File,
  jobId: string,
  source: CandidateSource,
): Promise<BulkResult> {
  const originalFilename =
    file.name || "resume.pdf";

  if (
    !originalFilename
      .toLowerCase()
      .endsWith(".pdf")
  ) {
    return {
      filename: originalFilename,
      success: false,
      error:
        "Only PDF resumes are supported.",
    };
  }

  if (file.size <= 0) {
    return {
      filename: originalFilename,
      success: false,
      error: "Uploaded PDF is empty.",
    };
  }

  if (file.size > MAX_FILE_SIZE) {
    return {
      filename: originalFilename,
      success: false,
      error: "Resume must be under 5 MB.",
    };
  }

  const filename = `${randomUUID()}.pdf`;

  const filePath = path.join(
    UPLOADS_DIR,
    filename,
  );
  let createdCandidateId: string | null = null;
  try {
    const bytes = new Uint8Array(
      await file.arrayBuffer(),
    );

    if (bytes.byteLength === 0) {
      throw new Error(
        "Uploaded PDF buffer is empty.",
      );
    }

    await mkdir(
      UPLOADS_DIR,
      { recursive: true },
    );

    await writeFile(
      filePath,
      Buffer.from(bytes),
    );

    const savedFile =
      await stat(filePath);

    if (savedFile.size === 0) {
      throw new Error(
        "Saved PDF is empty.",
      );
    }

    logger.info(
      {
        filename: originalFilename,
        savedPath: filePath,
        bytes: savedFile.size,
      },
      "Bulk upload: PDF saved",
    );

    const extracted =
      await extractResumeTextFromFile(
        filePath,
      );

    const resumeText =
      extracted.text.trim();

    if (!resumeText) {
      throw new Error(
        "Could not extract any text from the PDF, including OCR.",
      );
    }

    const email =
      extractEmailFromText(
        resumeText,
      );

    const name =
      extractNameFromText(
        resumeText,
        originalFilename,
      );

    if (!email) {
      throw new Error(
        "Could not find a candidate email address in the resume.",
      );
    }

    const candidate =
      await prisma.candidate.create({
        data: {
          name,
          email,
          resumePath:
            `/api/uploads/${filename}`,
          resumeText,
          status:
            CandidateStatus.APPLIED,
          appliedAt: new Date(),
          jobId,
          source,
          consentGiven: true,
          consentAt: new Date(),
          privacyPolicyVersion:
            PRIVACY_POLICY_VERSION,
        },
      });
    createdCandidateId = candidate.id;
    logger.info(
      {
        candidateId: candidate.id,
        filename: originalFilename,
        jobId,
        source,
        usedOcr:
          extracted.usedOcr,
      },
      "Bulk upload: candidate created",
    );

    await runEvaluationPipelineDirect(candidate.id);

    return {
      filename: originalFilename,
      success: true,
      candidateId: candidate.id,
      name,
      email,
    };
  } catch (error) {
    logger.error(
      {
        filename: originalFilename,
        error,
      },
      "Bulk upload: file processing failed",
    );

    await unlink(filePath).catch(
      () => undefined,
    );

    return {
      filename: originalFilename,
      success: false,
      error:
        error instanceof Error
          ? error.message
          : "Failed to process resume.",
    };
  }
}

async function runWithConcurrency(
  files: File[],
  jobId: string,
  source: CandidateSource,
): Promise<BulkResult[]> {
  const results: BulkResult[] =
    new Array(files.length);

  let nextIndex = 0;

  async function worker(): Promise<void> {
    while (true) {
      const index = nextIndex;
      nextIndex += 1;

      if (index >= files.length) {
        return;
      }

      results[index] =
        await processOneFile(
          files[index],
          jobId,
          source,
        );
    }
  }

  const workerCount = Math.min(
    CONCURRENCY,
    files.length,
  );

  await Promise.all(
    Array.from(
      { length: workerCount },
      () => worker(),
    ),
  );

  return results;
}

export async function POST(
  req: NextRequest,
) {
  const session = await auth();

  if (!session) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 },
    );
  }

  const isAdmin =
    (session.user as {
      role?: string;
    }).role === "ADMIN";

  const currentUserId =
    session.user?.id;

  if (!isAdmin && !currentUserId) {
    return NextResponse.json(
      {
        error:
          "Session is stale. Please sign in again.",
      },
      { status: 401 },
    );
  }

  try {
    const formData =
      await req.formData();

    const jobId =
      getFirstString(
        formData.get("jobId"),
      );

    const rawSource =
      getFirstString(
        formData.get("source"),
      ) || "WEBSITE";

    const sourceValue =
      rawSource.toUpperCase();

    if (!jobId) {
      return NextResponse.json(
        {
          error:
            "A job must be selected.",
        },
        { status: 400 },
      );
    }

    if (!VALID_SOURCES.has(sourceValue)) {
      return NextResponse.json(
        {
          error:
            "Invalid candidate source.",
        },
        { status: 400 },
      );
    }

    const source =
      sourceValue as CandidateSource;

    const job =
      await prisma.job.findFirst({
        where: {
          id: jobId,
          ...(
            !isAdmin && currentUserId
              ? {
                  createdById:
                    currentUserId,
                }
              : {}
          ),
        },
        select: {
          id: true,
          title: true,
        },
      });

    if (!job) {
      return NextResponse.json(
        {
          error:
            "Job not found or you do not have access to it.",
        },
        { status: 404 },
      );
    }

    const files =
      getFiles(formData);

    if (files.length === 0) {
      return NextResponse.json(
        {
          error:
            "No PDF resumes were uploaded.",
        },
        { status: 400 },
      );
    }

    if (files.length > MAX_FILES) {
      return NextResponse.json(
        {
          error:
            `You can upload a maximum of ${MAX_FILES} resumes at once.`,
        },
        { status: 400 },
      );
    }

    logger.info(
      {
        jobId,
        jobTitle: job.title,
        source,
        fileCount: files.length,
        concurrency: CONCURRENCY,
      },
      "Bulk upload: starting batch",
    );

    const results =
      await runWithConcurrency(
        files,
        jobId,
        source,
      );

    const successful =
      results.filter(
        (result) => result.success,
      ).length;

    const failed =
      results.length - successful;

    logger.info(
      {
        jobId,
        source,
        total: results.length,
        successful,
        failed,
      },
      "Bulk upload: batch complete",
    );

    return NextResponse.json(
      {
        jobId,
        jobTitle: job.title,
        source,
        total: results.length,
        successful,
        failed,
        concurrency: CONCURRENCY,
        results,
      },
      { status: 200 },
    );
  } catch (error) {
    logger.error(
      { error },
      "Bulk upload: unexpected error",
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Bulk upload failed.",
      },
      { status: 500 },
    );
  }
}
