"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  CheckIcon,
  DotsThreeIcon,
  XIcon,
} from "@phosphor-icons/react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
type Candidate = {
  id: string;
  name: string;
  resumePath: string | null;
  email: string;
  source: string;
  status: string;
  appliedAt: Date | string;
  job: {
    id: string;
    title: string;
  } | null;
  evaluation: {
    score: number | null;
    reasoning: string | null;
    pros: string | null;
    cons: string | null;
    promptSnapshot: string | null;
  } | null;
};

const STATUS_VARIANT: Record<
  string,
  "default" | "secondary" | "destructive" | "outline"
> = {
  APPLIED: "secondary",
  ANALYZING: "secondary",
  SHORTLISTED: "default",
  REJECTED: "destructive",
  ACCEPTED: "default",
};

function ActionButtons({ candidate }: { candidate: Candidate }) {
  async function decide(
    decision: "ACCEPT" | "SHORTLIST" | "REJECT",
  ) {
    const response = await fetch(
      `/api/recruiter/review/${candidate.id}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ decision }),
      },
    );

    if (!response.ok) {
      const data = await response.json().catch(() => null);
      alert(data?.error ?? "Could not update candidate.");
      return;
    }

    window.location.reload();
  }

  return (
    <div className="flex items-center justify-end gap-2">
      {candidate.resumePath && (
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            window.open(candidate.resumePath!, "_blank", "noopener,noreferrer");
          }}
        >
          View Resume
        </Button>
      )}
      <Button
        size="sm"
        variant="outline"
        onClick={() => decide("SHORTLIST")}
      >
        <CheckIcon size={16} className="mr-1" />
        Shortlist
      </Button>

      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button size="sm" variant="outline">
            <XIcon size={16} className="mr-1" />
            Reject
          </Button>
        </AlertDialogTrigger>

        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Reject candidate?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will mark {candidate.name} as rejected and trigger
              the rejection email if email delivery is configured.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => decide("REJECT")}
            >
              Reject Candidate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Popover>
        <PopoverTrigger asChild>
          <Button size="icon" variant="ghost">
            <DotsThreeIcon size={20} />
          </Button>
        </PopoverTrigger>

        <PopoverContent align="end" className="w-40">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => decide("ACCEPT")}
          >
            Accept
          </Button>
        </PopoverContent>
      </Popover>
    </div>
  );
}

function formatDate(value: Date | string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleDateString();
}

function formatSource(source: string) {
  const labels: Record<string, string> = {
    WEBSITE: "Website",
    EMAIL: "Email",
    LINKEDIN: "LinkedIn",
    PEOPLEHUM: "PeopleHum",
    WHATSAPP: "WhatsApp",
    REFERRAL: "Referral",
    JOB_PORTAL: "Job Portal",
    OTHER: "Other",
  };

  return labels[source] ?? source;
}

export default function CandidatesTable({
  candidates,
}: {
  candidates: Candidate[];
}) {
  if (candidates.length === 0) {
    return (
      <div className="p-8 text-center text-sm text-muted-foreground">
        No candidates found.
      </div>
    );
  }

  return (
    <div className="w-full overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Candidate</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>AI Score</TableHead>
            <TableHead>Applied</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>

        <TableBody>
          {candidates.map((candidate) => (
            <TableRow key={candidate.id}>
              <TableCell>
                <div className="font-medium">
                  {candidate.name}
                </div>
              </TableCell>

              <TableCell>
                {candidate.job?.title ?? "-"}
              </TableCell>

              <TableCell>
                <span className="text-sm">
                  {candidate.email}
                </span>
              </TableCell>

              <TableCell>
                <Badge variant="outline">
                  {formatSource(candidate.source)}
                </Badge>
              </TableCell>

              <TableCell>
                <Badge
                  variant={
                    STATUS_VARIANT[candidate.status] ??
                    "outline"
                  }
                >
                  {candidate.status}
                </Badge>
              </TableCell>

              <TableCell>
                {candidate.evaluation?.score ?? "-"}
              </TableCell>

              <TableCell>
                {formatDate(candidate.appliedAt)}
              </TableCell>

              <TableCell className="text-right">
                <ActionButtons candidate={candidate} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}