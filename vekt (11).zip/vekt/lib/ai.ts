import { createHash } from "crypto";
import logger from "@/lib/logger";
import { redactIdentity } from "@/lib/redact";
import {
  calculateWeightedScore,
  parseScoringProfile,
  type CriterionScores,
} from "@/lib/scoring";

export interface EvaluationResult {
  score: number;
  criteria: CriterionScores;
  reasoning: string;
  pros: string[];
  cons: string[];
}

/**
 * Provenance recorded alongside every evaluation.
 */
export interface EvaluationProvenance {
  provider: string;
  model: string;
  /** SHA-256 of the exact system prompt + user prompt sent to the provider. */
  promptHash: string;
  /** Bumped by hand whenever SYSTEM_PROMPT or buildPrompt changes. */
  evaluatorVersion: string;
  /** Redaction counts by category, e.g. { email: 1, phone: 1, name: 3 }. */
  redactions: Record<string, number>;
}

/**
 * Bump this whenever the prompt, scoring instructions or redaction
 * behaviour changes.
 */
export const EVALUATOR_VERSION = "2026.10.09";

type RuntimeCriterionScore = {
  score: number;
  evidence: string;
  matchType?:
    | "DIRECT"
    | "TRANSFERABLE"
    | "EMERGING"
    | "ADJACENT"
    | "NO_EVIDENCE";
};

const SYSTEM_PROMPT = `
MATCH TYPE OUTPUT CONTRACT:

For EVERY configured criterion, the JSON response MUST include:
- score: integer from 0 to 100
- evidence: grounded evidence from the candidate resume
- matchType: exactly one of DIRECT, TRANSFERABLE, EMERGING, ADJACENT, NO_EVIDENCE

Never omit matchType.
 
COMPACT JSON OUTPUT REQUIREMENTS — CRITICAL:

The Ollama output must remain very small so it can finish valid JSON within the existing 900-token generation limit.

Return ONLY the fields required by the evaluator:
- criteria
- reasoning

Do NOT return pros.
Do NOT return cons.
Do NOT repeat the full resume.
Do NOT quote long resume passages.
Do NOT include markdown.
Do NOT include commentary outside JSON.

For EVERY criterion return exactly:
{
  "score": 0,
  "evidence": "No evidence in resume.",
  "matchType": "NO_EVIDENCE"
}

Evidence MUST be a short faithful phrase of at most 12 words.
Use one concise sentence or phrase only.
Never copy multiple resume bullets into evidence.
Never concatenate multiple pieces of evidence.
Do not repeat the same evidence unnecessarily.

reasoning MUST be one concise sentence of at most 20 words.

The complete JSON response should normally remain well below 500 output tokens.

Example compact criterion:
"tools": {
  "score": 85,
  "evidence": "Used Figma for wireframes, prototypes, and usability testing.",
  "matchType": "DIRECT"
}

Example no-evidence criterion:
"domain_knowledge": {
  "score": 0,
  "evidence": "No evidence in resume.",
  "matchType": "NO_EVIDENCE"
}

A candidate's resume evidence must NEVER be expanded merely to fill the response.


DIRECT = directly relevant demonstrated work.
TRANSFERABLE = a specific capability that genuinely transfers to THIS criterion and THIS job.
EMERGING = relevant fresher, academic, internship, project, portfolio, certification, or early-career evidence.
ADJACENT = real resume evidence that does NOT meaningfully demonstrate THIS criterion for THIS job.
NO_EVIDENCE = the resume does not provide meaningful evidence for THIS criterion.

ADJACENT and NO_EVIDENCE must receive score 0.
Do not use TRANSFERABLE merely because the candidate has general workplace or technical experience.

You are an expert recruitment screening AI called Vekt.

Your task is to evaluate a candidate resume against a job description and a deterministic scoring profile.

PRIVACY:
- Do not use candidate identity information when scoring.
- Ignore name, email, phone, photo, age, gender, address, nationality, and similar personal identifiers.

SCORING:
- Evaluate EVERY criterion exactly once.
- Use the exact criterion IDs supplied by Vekt.
- Give each criterion an integer score from 0 to 100.
- Give specific evidence for every criterion.
- The candidate resume is the ONLY allowed source of candidate evidence.
- The job description defines the target being evaluated, but it is NEVER evidence that the candidate possesses anything.
- The scoring profile defines criterion names and weights, but it is NEVER evidence that the candidate possesses anything.
- Never turn a job requirement into a candidate fact.
- Never assume that because the job asks for Figma, Sketch, Adobe XD, React, HTML, CSS, WCAG, motion design, or another skill, the candidate has that skill.
- Give credit only when the candidate resume explicitly supports the skill or experience.
- If the resume does not explicitly support a capability, say exactly: "No evidence in resume."
- Do not infer Figma from UX/UI.
- Do not infer React from HTML/CSS.
- Do not infer accessibility/WCAG from general UX experience.
- Do not infer motion design from visual design.
- Do not infer portfolio quality from project names alone.
- Evidence must be an exact resume excerpt or a faithful excerpt that is directly supported by the resume.
- Never use wording copied from the job description as evidence of candidate experience.
- Never invent experience, skills, projects, employers, education, qualifications, certifications, or results.
- If evidence is absent, explicitly say that the evidence is absent.
- If evidence is present anywhere in the resume, do NOT describe it as absent.
- Search the entire resume before concluding that a skill or qualification is missing.
- Treat equivalent wording carefully. For example, "basic React collaboration" is evidence that React is mentioned; it is not evidence of "no React experience."
- A skill appearing in a Skills section, Experience section, Portfolio section, Education section, or Certification section is still valid resume evidence.
- Use exact quotations or faithful paraphrases from the resume whenever possible.
- Evidence, reasoning, Pros, and Cons must use plain text only.
- Do not use emojis, emoji shortcodes such as :health: or :user:, Markdown formatting, bullet symbols, or decorative Unicode characters.
- Use normal ASCII punctuation such as "-" and ":".
- Do not infer a qualification merely because another skill is present.


RECRUITER SCORING RULES 2026.10.01:

RELEVANCE IS REQUIRED:
- Evidence must support THIS criterion for THIS job.
- A resume phrase being present does not automatically make it relevant.
- Do not award role-specific experience merely because the candidate has a professional job.
- Evaluate actual responsibilities, projects, outcomes, and demonstrated work, not job title alone.

CORE ROLE EXPERIENCE:
- Direct target-role experience receives the strongest credit.
- Transferable experience may receive meaningful partial credit when the actual responsibilities genuinely map to the target role.
- Adjacent but unrelated experience receives little or no credit.
- Do NOT treat Data Science, AI, quantitative finance, analytics, generic software engineering, or research as UX/UI experience unless the resume explicitly demonstrates UX/UI responsibilities.
- Years of experience must never be invented.

POSITIVE RELEVANCE CHECK - UX/UI ROLES:
- For a UX/UI Designer job, explicit UX/UI responsibilities are DIRECT evidence for core role experience, even if the candidate's exact job title differs.
- Explicit UX/UI design, interaction design, product design, user experience design, or user interface design responsibilities are NOT ADJACENT.
- UX/UI portfolio projects, case studies, prototypes, wireframes, user flows, usability testing, user research, information architecture, interaction design, and design iterations are relevant evidence for the appropriate criterion.
- Explicit use of Figma, Sketch, or Adobe XD is direct evidence for the tools criterion when the resume states that the candidate used the tool.
- Explicit collaboration with product managers, engineers, developers, researchers, or stakeholders is relevant evidence for communication and collaboration when the resume describes that collaboration.
- Explicit accessibility work, including WCAG or accessible design, is relevant evidence when stated in the resume.
- Genuine UX/UI work remains relevant even when performed as an internal product, academic project, independent project, portfolio project, or different industry.
- Do NOT classify genuine UX/UI responsibilities or demonstrated UX/UI project work as ADJACENT merely because the work was not performed under the exact target job title.
- ADJACENT is reserved for evidence that is genuinely from another field or capability and does not meaningfully demonstrate THIS criterion.
- Before assigning ADJACENT, ask: "Does this evidence actually demonstrate the capability measured by this criterion for this job?" If yes, it must NOT be ADJACENT.

CAREER SWITCHERS:
- A career switcher does NOT need a previous job title matching the target role.
- Give meaningful credit for relevant previous responsibilities, independent projects, portfolio work, internships, and demonstrated skills.
- Do not falsely describe transferable experience as professional employment in the target role.

FRESHERS:
- Relevant academic projects, internships, personal projects, portfolio work, coursework, certifications, competitions, and demonstrated work can provide evidence.
- Lack of full-time experience alone must not force every criterion to zero.

ROLE-SPECIFIC SKILLS:
- Do not infer Figma from UX/UI.
- Do not infer Sketch or Adobe XD from general design.
- Do not infer React from HTML/CSS.
- Do not infer WCAG from generic accessibility language.
- Do not infer user research from generic communication or analytics.
- Do not infer motion design from visual design.
- Do not infer UX/UI from general technology experience.

PORTFOLIO:
- Concrete case studies, prototypes, wireframes, user research, usability testing, design iterations, shipped work, and documented projects are valid portfolio evidence when relevant.
- Do not dismiss portfolio evidence merely because it is an independent or academic project.

DOMAIN:
- Award domain knowledge only when the resume contains actual evidence relevant to the target job domain.
- General technology experience is not automatically domain knowledge.

CRITERION INDEPENDENCE:
- Evaluate every criterion independently.
- Do not copy one score across criteria.
- The same resume evidence may support multiple criteria only when it genuinely supports each criterion.
- Do not let one missing skill zero unrelated criteria.
- For each criterion, first determine exactly what that criterion measures, then select evidence that directly demonstrates that criterion.
- If an excerpt is relevant to the candidate generally but does not demonstrate THIS criterion, use exactly: "No evidence in resume."
- Do not reuse an evidence excerpt merely because it is relevant to UX/UI generally; reuse is allowed only when the same excerpt directly demonstrates both criteria.

SCORING:
- 0 = no meaningful evidence or irrelevant evidence.
- 1-29 = very weak or highly indirect relevant evidence.
- 30-49 = limited but meaningful relevant evidence.
- 50-69 = moderate relevant evidence, transferable evidence, or strong emerging/fresher evidence.
- 70-89 = strong relevant evidence.
- 90-100 = extensive and highly relevant evidence.
- These ranges are guidance, not automatic scores.

MATCH TYPE - REQUIRED:
- For EVERY criterion return exactly one matchType:
  DIRECT, TRANSFERABLE, EMERGING, ADJACENT, or NO_EVIDENCE.
- DIRECT means the resume demonstrates the criterion through directly relevant professional work or clearly relevant demonstrated work.
- TRANSFERABLE means the resume demonstrates a capability from another context that genuinely transfers to THIS criterion and THIS job.
- EMERGING means relevant evidence exists through a fresher-level project, academic work, internship, portfolio, certification, or early experience.
- ADJACENT means the evidence is real but belongs to another field or capability and does NOT meaningfully demonstrate THIS criterion for THIS job.
- NO_EVIDENCE means the resume does not provide meaningful evidence for THIS criterion.
- ADJACENT MUST receive score 0.
- NO_EVIDENCE MUST receive score 0.
- Do NOT call unrelated technical, analytical, business, or professional experience TRANSFERABLE merely because the candidate has transferable workplace skills.
- Transferability must be specific to the criterion. For example, stakeholder communication can transfer to communication/collaboration, but Data Science experience does not become UX/UI design experience.
- A candidate does NOT need the target job title to receive DIRECT, TRANSFERABLE, or EMERGING credit.
- Career switchers and freshers can receive meaningful scores when their resume contains relevant projects, portfolio work, internships, academic work, or genuinely transferable evidence.
- Do not use job title alone to determine matchType.

GROUNDING:
- Every evidence statement must be supported by the resume.
- Faithful paraphrases are allowed.
- Do not invent facts merely to make an evidence statement match the criterion.
- If the resume contains relevant evidence but uses different wording, describe that evidence faithfully rather than declaring it absent.

PROS AND CONS:
- Every Pro and Con must ultimately be supported by the candidate resume. The job description may explain why a capability matters, but it cannot prove that the candidate has that capability.
- Before writing Pros or Cons, cross-check every statement against the full resume.
- NEVER write that something is missing if it actually appears anywhere in the resume.
- Do not repeat the same weakness in different wording.
- Prefer a small number of precise Pros and Cons over many speculative ones.
- Do not downgrade a candidate because the resume uses wording that differs from the job description when the underlying skill is clearly present.

IMPORTANT:
- You provide criterion-level scores and evidence.
- Vekt calculates the final weighted score separately.
- Do NOT provide a top-level final score.
- Do NOT make a hiring decision.
- Do NOT recommend shortlist, reject, or accept.

Return valid JSON only.

The JSON must have exactly these fields:
{
  "criteria": {
    "<criterion_id>": {
      "score": <integer 0-100>,
      "evidence": "<exact resume evidence excerpt, or exactly: No evidence in resume.>"
    }
  },
  "reasoning": "<exactly 2 sentences summarizing the evidence across the criteria>",
  "pros": ["<supported positive 1>", "<supported positive 2>"],
  "cons": ["<supported limitation 1>", "<supported limitation 2>"]
}`;

function truncateForLog(value: string, max = 600): string {
  if (value.length <= max) return value;
  return `${value.slice(0, max)}... [truncated ${value.length - max} chars]`;
}

function buildPrompt(
  jobTitle: string,
  jobDescription: string,
  customPrompt: string | null,
  scoringProfile: ReturnType<typeof parseScoringProfile>,
  resumeText: string,
): string {
  const parts: string[] = [
    `<JOB_TITLE>
${jobTitle}
</JOB_TITLE>`,

    `<JOB_DESCRIPTION>
This section defines what the employer is asking for.
It is NOT candidate evidence.
Do not use any statement in this section as proof that the candidate
has a skill, tool, qualification, experience, project, or achievement.

${jobDescription}
</JOB_DESCRIPTION>`,

    `<DETERMINISTIC_SCORING_PROFILE>
This section defines criterion names and weights.
It is NOT candidate evidence.

${JSON.stringify(scoringProfile, null, 2)}
</DETERMINISTIC_SCORING_PROFILE>`,
  ];

  if (customPrompt) {
    parts.push(
      `## Additional Job-Specific Instructions\n${customPrompt}`,
    );
  }

  parts.push(`<CANDIDATE_RESUME>
THIS IS THE ONLY SOURCE OF CANDIDATE EVIDENCE.

Use only this section when stating that the candidate has a skill,
tool, technology, qualification, responsibility, project, achievement,
or other capability.

${resumeText}
</CANDIDATE_RESUME>`);

  return parts.join("\n\n");
}


function getDeterministicRelevantScore(
  criterionId: string,
  evidence: string,
  evaluationPrompt: string,
  aiScore: number,
): { relevant: boolean; score: number; matchType: RuntimeCriterionScore["matchType"] } {
  const jobIsUxUi =
    /\b(ux\/ui|ux ui|user experience|user interface|interaction design|product design)\b/i.test(
      evaluationPrompt,
    );

  if (!jobIsUxUi) {
    return {
      relevant: false,
      score: aiScore,
      matchType: "ADJACENT",
    };
  }

  const text = evidence.toLowerCase();

  const directUxRole =
    /\b(ux\/ui designer|ux designer|ui designer|user experience designer|user interface designer|interaction designer|product designer)\b/i.test(
      text,
    );

  const uxResponsibilities =
    /\b(user experience|user interface|interaction design|product design|wireframe|wireframes|prototype|prototypes|user research|user interview|usability testing|information architecture|user flow|journey map|journey mapping|redesign|onboarding flow)\b/i.test(
      text,
    );

  const uxTools =
    /\b(figma|sketch|adobe xd)\b/i.test(text);

  const portfolioEvidence =
    /\b(portfolio|selected work|case study|case studies|project|projects|wireframe|wireframes|prototype|prototypes|user flow|journey map|information architecture|interaction design|usability testing)\b/i.test(
      text,
    );

  const problemSolvingEvidence =
    /\b(redesign|redesigned|friction|drop-off|drop off|usability|user research|user interview|iteration|iterated|improv(ed|ement)|reduced|increased|decreased|problem|onboarding|time-to-|conversion)\b/i.test(
      text,
    );

  const communicationEvidence =
    /\b(collaborat(ed|ion|ing)?|product manager|product managers|engineer|engineers|developer|developers|stakeholder|stakeholders|present(ed|ation)|research findings|requirements)\b/i.test(
      text,
    );

  const accessibilityEvidence =
    /\b(wcag|accessibility|accessible design)\b/i.test(text);

  const bonusEvidence =
    /\b(motion design|micro-interaction|micro-interactions|animation|animated)\b/i.test(
      text,
    );

  if (criterionId === "core_experience") {
    if (directUxRole || (uxResponsibilities && /\b(design|designer|ux|ui)\b/i.test(text))) {
      return {
        relevant: true,
        score: Math.max(aiScore, directUxRole ? 85 : 70),
        matchType: directUxRole ? "DIRECT" : "TRANSFERABLE",
      };
    }
  }

  if (criterionId === "portfolio" && portfolioEvidence) {
    return {
      relevant: true,
      score: Math.max(aiScore, 80),
      matchType: "DIRECT",
    };
  }

  if (criterionId === "tools" && uxTools) {
    return {
      relevant: true,
      score: Math.max(aiScore, 85),
      matchType: "DIRECT",
    };
  }

  if (criterionId === "domain_knowledge" && (uxResponsibilities || accessibilityEvidence)) {
    return {
      relevant: true,
      score: Math.max(aiScore, 70),
      matchType: "DIRECT",
    };
  }

  if (criterionId === "problem_solving" && problemSolvingEvidence) {
    return {
      relevant: true,
      score: Math.max(aiScore, 70),
      matchType: "DIRECT",
    };
  }

  if (criterionId === "communication" && communicationEvidence) {
    return {
      relevant: true,
      score: Math.max(aiScore, 70),
      matchType: "DIRECT",
    };
  }

  if (criterionId === "bonus" && bonusEvidence) {
    return {
      relevant: true,
      score: Math.max(aiScore, 70),
      matchType: "DIRECT",
    };
  }

  return {
    relevant: false,
    score: 0,
    matchType: "ADJACENT",
  };
}
async function evaluateWithOpenAI(
  prompt: string,
  model = process.env.OPENAI_MODEL ?? "gpt-4o",
): Promise<{ result: EvaluationResult; model: string }> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is not set");

  logger.info(
    {
      provider: "openai",
      model,
      endpoint: "https://api.openai.com/v1/chat/completions",
    },
    "AI: sending evaluation request",
  );

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    logger.error(
      {
        provider: "openai",
        model,
        status: res.status,
        body: truncateForLog(body),
      },
      "AI: OpenAI request failed",
    );
    throw new Error(`OpenAI API error ${res.status}: ${body}`);
  }

  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error("Empty response from OpenAI");

  try {
    return { result: JSON.parse(content) as EvaluationResult, model };
  } catch (error) {
    logger.error(
      {
        provider: "openai",
        model,
        content: truncateForLog(String(content)),
        error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : error,},
      "AI: failed to parse OpenAI JSON response",
    );
    throw error;
  }
}

async function evaluateWithOpenRouter(
  prompt: string,
  model = process.env.OPENROUTER_MODEL ?? "openai/gpt-4o-mini",
): Promise<{ result: EvaluationResult; model: string }> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) throw new Error("OPENROUTER_API_KEY is not set");

  logger.info(
    {
      provider: "openrouter",
      model,
      endpoint: "https://openrouter.ai/api/v1/chat/completions",
    },
    "AI: sending evaluation request",
  );

  const res = await fetch(
    "https://openrouter.ai/api/v1/chat/completions",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        "HTTP-Referer": process.env.APP_URL ?? "http://localhost:3000",
        "X-Title": "Vekt",
      },
      body: JSON.stringify({
        model,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: prompt },
        ],
      }),
    },
  );

  if (!res.ok) {
    const body = await res.text();
    logger.error(
      {
        provider: "openrouter",
        model,
        status: res.status,
        body: truncateForLog(body),
      },
      "AI: OpenRouter request failed",
    );
    throw new Error(`OpenRouter API error ${res.status}: ${body}`);
  }

  const data = await res.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error("Empty response from OpenRouter");

  try {
    return { result: JSON.parse(content) as EvaluationResult, model };
  } catch (error) {
    logger.error(
      {
        provider: "openrouter",
        model,
        content: truncateForLog(String(content)),
        error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : error,},
      "AI: failed to parse OpenRouter JSON response",
    );
    throw error;
  }
}

async function evaluateWithOllama(
  prompt: string,
  model?: string,
): Promise<{ result: EvaluationResult; model: string }> {
  const baseUrl =
    process.env.OLLAMA_BASE_URL ?? "http://localhost:11434";
  const ollamaModel =
    model ?? process.env.OLLAMA_MODEL ?? "llama3.2";

  const requestStarted = Date.now();

  logger.info(
    {
      provider: "ollama",
      model: ollamaModel,
      endpoint: `${baseUrl}/api/chat`,
      promptChars: prompt.length,
      systemPromptChars: SYSTEM_PROMPT.length,
      keepAlive: "30m",
    },
    "AI: sending evaluation request",
  );

  const res = await fetch(`${baseUrl}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: ollamaModel,
      format: "json",
      stream: false,
      keep_alive: "30m",
      options: {
        temperature: 0,
        top_p: 0.8,
        repeat_penalty: 1.2,
        num_predict: 900,
      },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
    }),
  });

  const requestMs = Date.now() - requestStarted;

  if (!res.ok) {
    const body = await res.text();

    logger.error(
      {
        provider: "ollama",
        model: ollamaModel,
        status: res.status,
        requestMs,
        body: truncateForLog(body),
      },
      "AI: Ollama request failed",
    );

    throw new Error(`Ollama API error ${res.status}: ${body}`);
  }

  const data = await res.json();
  const content = data.message?.content;

  if (!content) {
    throw new Error("Empty response from Ollama");
  }

  logger.info(
    {
      provider: "ollama",
      model: ollamaModel,
      requestMs,
      totalDurationMs:
        typeof data.total_duration === "number"
          ? Math.round(data.total_duration / 1_000_000)
          : undefined,
      loadDurationMs:
        typeof data.load_duration === "number"
          ? Math.round(data.load_duration / 1_000_000)
          : undefined,
      promptEvalDurationMs:
        typeof data.prompt_eval_duration === "number"
          ? Math.round(data.prompt_eval_duration / 1_000_000)
          : undefined,
      evalDurationMs:
        typeof data.eval_duration === "number"
          ? Math.round(data.eval_duration / 1_000_000)
          : undefined,
      promptEvalCount: data.prompt_eval_count,
      evalCount: data.eval_count,
      responseChars: String(content).length,
    },
    "AI: Ollama timing",
  );

  try {
    return {
      result: JSON.parse(content) as EvaluationResult,
      model: ollamaModel,
    };
  } catch (error) {
    logger.error(
      {
        provider: "ollama",
        model: ollamaModel,
        requestMs,
        content: truncateForLog(String(content)),
        error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : error,},
      "AI: failed to parse Ollama JSON response",
    );

    throw error;
  }
}
function normalizeEvidenceText(value: string): string {
  return value
    .toLowerCase()
    .replace(/[“”"'`]/g, "")
    .replace(/[^a-z0-9+#./-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isNoEvidenceStatement(value: string): boolean {
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/^[-•*]\s*/, "")
    .replace(/^["']|["']$/g, "")
    .replace(/\s+/g, " ")
    .trim();

  return (
    normalized === "no evidence in resume." ||
    normalized === "no evidence in resume" ||
    normalized === "no evidence" ||
    normalized === "not mentioned in resume." ||
    normalized === "not mentioned in resume" ||
    normalized === "not stated in resume." ||
    normalized === "not stated in resume" ||
    normalized === "not found in resume." ||
    normalized === "not found in resume" ||
    normalized === "none" ||
    normalized === "n/a"
  );
}

function cleanEvidenceExcerpt(value: string): string {
  return value
    .replace(/^resume evidence\s*:\s*/i, "")
    .replace(/^evidence\s*:\s*/i, "")
    .trim()
    .replace(/^["“]+/, "")
    .replace(/["”]+$/, "")
    .trim();
}

function evidenceIsGroundedInResume(
  evidence: string,
  resumeText: string,
): boolean {
  const clean = cleanEvidenceExcerpt(evidence);

  if (isNoEvidenceStatement(clean)) {
    return true;
  }

  const resume = normalizeEvidenceText(resumeText);
  const excerpt = normalizeEvidenceText(clean);

  if (!excerpt) {
    return false;
  }

  const stopWords = new Set([
    "the", "and", "for", "with", "from", "that", "this",
    "have", "has", "had", "was", "were", "are", "been",
    "being", "into", "their", "they", "them", "candidate",
    "experience", "work", "using", "used", "based", "strong",
  ]);

  const tokens = Array.from(
    new Set(
      excerpt
        .split(/[^a-z0-9+#.]+/i)
        .map((token) => token.trim())
        .filter((token) => token.length >= 4 && !stopWords.has(token)),
    ),
  );

  if (tokens.length < 3) {
    return false;
  }

  const matchedTokens = tokens.filter((token) => resume.includes(token));

  return matchedTokens.length / tokens.length >= 0.8;
}
export async function evaluateCandidate(params: {
  jobTitle: string;
  jobDescription: string;
  customPrompt: string | null;
  resumeText: string;
  candidateName?: string;
  scoringProfile?: string | null;
}): Promise<{
  result: EvaluationResult;
  promptSnapshot: string;
  provenance: EvaluationProvenance;
}> {
  const provider =
    (process.env.AI_PROVIDER ?? "mock").toLowerCase();

  logger.info({ provider }, "AI: selected evaluation provider");

  // Strip direct identifiers before anything reaches the provider.
  const redacted = redactIdentity(
    params.resumeText,
    params.candidateName,
  );

  const scoringProfile = parseScoringProfile(
    params.scoringProfile,
  );

  const prompt = buildPrompt(
    params.jobTitle,
    params.jobDescription,
    params.customPrompt,
    scoringProfile,
    redacted.text,
  );

  const promptSnapshot =
    `${SYSTEM_PROMPT}\n\n---\n\n${prompt}`;

  const promptHash = createHash("sha256")
    .update(promptSnapshot)
    .digest("hex");

  let result: EvaluationResult;
  let model: string;

  try {
    if (provider === "openai") {
      ({ result, model } = await evaluateWithOpenAI(prompt));
    } else if (provider === "openrouter") {
      ({ result, model } = await evaluateWithOpenRouter(prompt));
    } else if (provider === "ollama") {
      ({ result, model } = await evaluateWithOllama(prompt));
    } else {
      // Mock provider - deterministic for a given prompt.
      logger.info(
        { provider: "mock" },
        "AI: using mock evaluation provider",
      );

      await new Promise((r) => setTimeout(r, 600));

      model = "mock";

      const seed = parseInt(promptHash.slice(0, 8), 16);
      const score = 40 + (seed % 61);

      const mockCriteria: CriterionScores = {};

      for (const criterion of scoringProfile) {
        mockCriteria[criterion.id] = {
          score,
          evidence: "Mock provider - no assessment performed.",
        };
      }

      result = {
        score: 0,
        criteria: mockCriteria,
        reasoning:
          `Mock evaluation for the ${params.jobTitle} role. ` +
          "This evaluation is generated for development and carries no assessment of the candidate.",
        pros: ["Mock provider - no assessment performed"],
        cons: ["Mock provider - no assessment performed"],
      };
    }
  } catch (error) {
    logger.error(
      {
        provider,
        jobTitle: params.jobTitle,
        hasCustomPrompt: Boolean(params.customPrompt),
        resumeLength: params.resumeText.length,
        error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : error,},
      "AI: evaluation provider failed",
    );
    throw error;
  }

  // Validate required fields.
  if (
    typeof result.reasoning !== "string" ||
    !Array.isArray(result.pros) ||
    !Array.isArray(result.cons) ||
    !result.criteria ||
    typeof result.criteria !== "object" ||
    Array.isArray(result.criteria)
  ) {
    logger.error(
      { provider, result },
      "AI: evaluation response missing required criterion fields",
    );

    throw new Error(
      `AI returned malformed criterion evaluation: ${JSON.stringify(result)}`,
    );
  }

  // Normalize every configured criterion.
  // AI supplies score + evidence + matchType.
  // Vekt deterministically enforces relevance.

  const normalizedCriteria: Record<
    string,
    RuntimeCriterionScore
  > = {};

  for (const criterion of scoringProfile) {
    const raw = result.criteria[criterion.id];

    if (!raw || typeof raw !== "object") {
      logger.warn(
        { criterionId: criterion.id },
        "AI response was missing criterion; defaulting to no evidence",
      );

      normalizedCriteria[criterion.id] = {
        score: 0,
        evidence: "No evidence in resume.",
        matchType: "NO_EVIDENCE",
      };

      continue;
    }

    const rawScore = Number(raw.score);
    const evidence = String(raw.evidence ?? "").trim();

    const rawMatchType = String(
      (raw as unknown as { matchType?: unknown }).matchType ?? "",
    )
      .trim()
      .toUpperCase();

    const validMatchTypes = [
      "DIRECT",
      "TRANSFERABLE",
      "EMERGING",
      "ADJACENT",
      "NO_EVIDENCE",
    ];

    const matchType = validMatchTypes.includes(rawMatchType)
      ? rawMatchType as RuntimeCriterionScore["matchType"]
      : evidence === "No evidence in resume."
        ? "NO_EVIDENCE"
        : "ADJACENT";

    if (!Number.isFinite(rawScore)) {
      throw new Error(
        `AI returned an invalid score for criterion: ${criterion.id}`,
      );
    }

    if (!evidence) {
      normalizedCriteria[criterion.id] = {
        score: 0,
        evidence: "No evidence in resume.",
        matchType: "NO_EVIDENCE",
      };

      continue;
    }

    if (!evidenceIsGroundedInResume(evidence, redacted.text)) {
      logger.warn(
        {
          criterionId: criterion.id,
          aiScore: rawScore,
          evidence,
        },
        "AI evidence was not grounded in resume; criterion treated as no evidence",
      );

      normalizedCriteria[criterion.id] = {
        score: 0,
        evidence: "No evidence in resume.",
        matchType: "NO_EVIDENCE",
      };

      continue;
    }

    let score = Math.max(
      0,
      Math.min(100, Math.round(rawScore)),
    );

    let normalizedEvidence = evidence;

    /*
     * FINAL UX/UI RELEVANCE SAFETY NET
     *
     * Qwen can occasionally return:
     *   matchType = NO_EVIDENCE
     *   score     = 0
     * while simultaneously returning real grounded evidence.
     *
     * Evidence is the authoritative signal here.  If the resume contains
     * explicit UX/UI evidence, do not let a contradictory AI matchType
     * erase it.
     */
    if (
      evidence &&
      evidence !== "No evidence in resume." &&
      /\b(ux\/ui|ux ui|ux designer|ui designer|user experience|user interface|interaction design|product design|wireframe|wireframes|prototype|prototypes|user research|user interview|usability testing|information architecture|user flow|journey map|redesign|figma|sketch|adobe xd|wcag|accessibility|design system|design systems)\b/i.test(
        evidence,
      )
    ) {
      const uxJob = /\b(ux\/ui|ux ui|user experience|user interface|interaction design|product design)\b/i.test(
        prompt,
      );

      if (uxJob) {
        let correctedMatchType:
          | "DIRECT"
          | "TRANSFERABLE"
          | "EMERGING"
          | "ADJACENT"
          | "NO_EVIDENCE" = "TRANSFERABLE";

        let minimumScore = 70;

        if (criterion.id === "core_experience") {
          if (
            /\b(ux\/ui designer|ux designer|ui designer|user experience designer|user interface designer|interaction designer|product designer|senior ux\/ui designer)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 85;
          }
        }

        if (criterion.id === "portfolio") {
          if (
            /\b(portfolio|selected work|case study|case studies|project|projects|prototype|prototypes|wireframe|wireframes|user flow|journey map)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 80;
          }
        }

        if (criterion.id === "tools") {
          if (
            /\b(figma|sketch|adobe xd)\b/i.test(evidence)
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 85;
          }
        }

        if (criterion.id === "domain_knowledge") {
          if (
            /\b(user research|user interview|usability testing|information architecture|interaction design|accessibility|wcag|design system|user experience|user interface)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 80;
          }
        }

        if (criterion.id === "problem_solving") {
          if (
            /\b(redesign|redesigned|friction|drop-off|drop off|usability|user research|user interview|improv|reduced|increased|decreased|iteration|onboarding|problem)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 70;
          }
        }

        if (criterion.id === "communication") {
          if (
            /\b(collaborat|product manager|product managers|engineer|engineers|developer|developers|stakeholder|stakeholders|present|research findings|requirements|handoff)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 70;
          }
        }

        if (criterion.id === "bonus") {
          if (
            /\b(motion design|micro-interaction|micro-interactions|animation|animated)\b/i.test(
              evidence,
            )
          ) {
            correctedMatchType = "DIRECT";
            minimumScore = 70;
          }
        }

        score = Math.max(score, minimumScore);

        normalizedCriteria[criterion.id] = {
          score,
          evidence: normalizedEvidence,
          matchType: correctedMatchType,
        };

        logger.info(
          {
            criterion: criterion.id,
            originalMatchType: matchType,
            correctedMatchType,
            score,
          },
          "AI: corrected contradictory matchType because grounded UX/UI evidence was present",
        );

        continue;
      }
    }

    if (matchType === "ADJACENT") {
      const corrected = getDeterministicRelevantScore(
        criterion.id,
        evidence,
        prompt,
        score,
      );

      if (corrected.relevant) {
        score = corrected.score;
        normalizedCriteria[criterion.id] = {
          score,
          evidence: normalizedEvidence,
          matchType: corrected.matchType,
        };

        logger.info(
          {
            criterion: criterion.id,
            originalMatchType: matchType,
            correctedMatchType: corrected.matchType,
            score,
          },
          "AI: corrected false ADJACENT classification using grounded job-relevant evidence",
        );

        continue;
      }

      score = 0;
    }

    if (matchType === "NO_EVIDENCE") {
      score = 0;
      normalizedEvidence = "No evidence in resume.";
    }

    normalizedCriteria[criterion.id] = {
      score,
      evidence: normalizedEvidence,
      matchType,
    };
  }

  const finalScore = calculateWeightedScore(
    scoringProfile,
    normalizedCriteria,
  );
  result.score = finalScore;
  result.criteria = normalizedCriteria;
  // Reasoning is generated deterministically from Vekt's normalized
  // criterion results so it cannot contradict the actual scores/evidence.
  const scoredCriteria = scoringProfile.map(
    (criterion) => ({
      criterion,
      score: normalizedCriteria[criterion.id].score,
      evidence: normalizedCriteria[criterion.id].evidence,
      matchType: normalizedCriteria[criterion.id].matchType,
    }),
  );

  const strengths = scoredCriteria
    .filter(
      (item) =>
        item.score >= 70 &&
        item.matchType !== "NO_EVIDENCE" &&
        item.matchType !== "ADJACENT",
    )
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  const gaps = scoredCriteria
    .filter(
      (item) =>
        item.criterion.id !== "bonus" &&
        item.score < 50,
    )
    .sort((a, b) => a.score - b.score)
    .slice(0, 3);

  result.pros =
    strengths.length > 0
      ? strengths.map(
          (item) =>
            `- ${item.criterion.label}: ${item.score}/100. ${item.evidence}`,
        )
      : [
          "- No strong positive criteria identified from the available resume evidence.",
        ];

  result.cons =
    gaps.length > 0
      ? gaps.map(
          (item) =>
            `- ${item.criterion.label}: ${item.score}/100. ${item.evidence}`,
        )
      : [
          "- No major scoring gaps identified in the configured core criteria.",
        ];

  const provenance: EvaluationProvenance = {
    provider,
    model,
    promptHash,
    evaluatorVersion: EVALUATOR_VERSION,
    redactions: redacted.counts,
  };

  logger.info(
    {
      provider,
      model,
      promptHash,
      evaluatorVersion: EVALUATOR_VERSION,
      score: result.score,
      criteria: result.criteria,
    },
    "AI: evaluation completed",
  );

  return {
    result,
    promptSnapshot,
    provenance,
  };
}
