import {
  CandidateStatus,
  EmailType,
} from "@/generated/client";

import { auth } from "@/lib/auth";
import { sendCandidateEmail } from "@/lib/email";
import {
  reviewDecisionSchema,
} from "@/lib/schemas";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
