﻿import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import BulkUploadForm from "./BulkUploadForm";

export default async function BulkUploadPage() {
  const session = await auth();
  if (!session) redirect("/login");

  const isAdmin = (session.user as { role?: string }).role === "ADMIN";
  const currentUserId = session.user?.id;
  if (!isAdmin && !currentUserId) redirect("/login");

  const jobs = await prisma.job.findMany({
    where: {
      isActive: true,
      ...(!isAdmin && currentUserId ? { createdById: currentUserId } : {}),
    },
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true },
  });

  return (
    <div className="min-h-[89vh] bg-background">
      <main className="mx-auto max-w-3xl p-6">
        <h1 className="text-lg font-semibold">Bulk Resume Upload</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Upload multiple PDFs into one job. Files are processed one at a time through your local AI.
        </p>
        <div className="mt-6">
          <BulkUploadForm jobs={jobs} />
        </div>
      </main>
    </div>
  );
}
