﻿import { EmailType } from "@/generated/client";
import { COMPANY_NAME } from "@/lib/brand";
import logger from "@/lib/logger";
import { prisma } from "@/lib/prisma";
import {
  createStatusToken,
  createUnsubscribeToken,
} from "@/lib/public-tokens";
import nodemailer from "nodemailer";

const APP_URL =
  process.env.APP_URL ?? "http://127.0.0.1:3000";

const FROM =
  process.env.EMAIL_FROM ??
  process.env.SMTP_USER ??
  "noreply@localhost";

function getTransporter() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT ?? "587");
  const secure =
    String(process.env.SMTP_SECURE ?? "false").toLowerCase() ===
    "true";
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
  });
}

function interpolate(
  template: string,
  vars: Record<string, string>,
): string {
  return template.replace(
    /\{\{(\w+)\}\}/g,
    (_, key: string) => vars[key] ?? `{{${key}}}`,
  );
}

export function getStatusPageUrl(
  candidateId: string,
): string {
  return `${APP_URL}/status/${createStatusToken(candidateId)}`;
}

export function getUnsubscribeUrl(
  candidateId: string,
): string {
  return `${APP_URL}/api/unsubscribe?token=${createUnsubscribeToken(candidateId)}`;
}

interface SendEmailOptions {
  candidateId: string;
  type: EmailType;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function textToHtml(text: string): string {
  return escapeHtml(text)
    .replace(/\r\n/g, "\n")
    .replace(/\n\n+/g, "</p><p>")
    .replace(/\n/g, "<br>");
}

export async function sendCandidateEmail({
  candidateId,
  type,
}: SendEmailOptions): Promise<void> {
  const transporter = getTransporter();

  if (!transporter) {
    logger.warn(
      { candidateId, type },
      "Email: SMTP is not configured; skipping",
    );

    return;
  }

  const candidate = await prisma.candidate.findUnique({
    where: { id: candidateId },
    include: {
      job: true,
    },
  });

  if (!candidate) {
    throw new Error(
      `Candidate ${candidateId} not found`,
    );
  }

  if (
    candidate.emailOptOut &&
    type !== EmailType.DATA_RETENTION_WARNING
  ) {
    logger.info(
      { candidateId, type },
      "Email: candidate has opted out",
    );

    return;
  }

  const template =
    await prisma.emailTemplate.findUnique({
      where: { type },
    });

  if (!template) {
    throw new Error(
      `Email template ${type} not found`,
    );
  }

  const statusPageUrl =
    getStatusPageUrl(candidate.id);

  const unsubscribeUrl =
    getUnsubscribeUrl(candidate.id);

  const variables = {
    candidateName: candidate.name,
    jobTitle:
      candidate.job?.title ?? "the position",
    companyName: COMPANY_NAME,
    applicationDate:
      candidate.appliedAt.toLocaleDateString(),
    candidateStatus: candidate.status,
    statusPageUrl,
    retentionDate:
      candidate.appliedAt.toLocaleDateString(),
  };

  const subject = interpolate(
    template.subject,
    variables,
  );

  const body = interpolate(
    template.body,
    variables,
  );

  const text = `${body}

Unsubscribe:
${unsubscribeUrl}`;

  const html = `
<!doctype html>
<html>
  <body style="font-family:Arial,Helvetica,sans-serif;line-height:1.6;color:#222;">
    <div style="max-width:640px;margin:0 auto;padding:24px;">
      ${textToHtml(body)}

      <hr style="margin:32px 0;border:0;border-top:1px solid #ddd;" />

      <p style="font-size:12px;color:#666;">
        <a href="${escapeHtml(unsubscribeUrl)}">
          Unsubscribe from candidate emails
        </a>
      </p>
    </div>
  </body>
</html>
`;

  try {
    const result = await transporter.sendMail({
      from: FROM,
      to: candidate.email,
      subject,
      text,
      html,
    });

    await prisma.emailLog.create({
      data: {
        candidateId: candidate.id,
        type,
        resendId: result.messageId ?? null,
      },
    });

    logger.info(
      {
        candidateId,
        type,
        messageId: result.messageId,
      },
      "Email: candidate email sent",
    );
  } catch (error) {
    logger.error(
      {
        candidateId,
        type,
        error,
      },
      "Email: candidate email failed",
    );

    throw error;
  }
}