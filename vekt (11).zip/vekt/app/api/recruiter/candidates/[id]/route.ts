import { unlink } from "fs/promises";
import path from "path";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import logger from "@/lib/logger";
import { NextResponse } from "next/server";

async function removeResumeFile(resumePath: string) {
  const candidates: string[] = [];

  if (resumePath) {
    if (path.isAbsolute(resumePath)) {
      candidates.push(resumePath);
    } else {
      candidates.push(path.resolve(process.cwd(), resumePath));
      candidates.push(
        path.resolve(
          process.cwd(),
          "private",
          "uploads",
          path.basename(resumePath),
        ),
      );
      candidates.push(path.resolve("C:\\Vekt\\vekt", resumePath));
    }
  }

  const uniquePaths = [...new Set(candidates)];

  const allowedUploadRoots = [
    path.normalize(
      path.resolve(process.cwd(), "private", "uploads"),
    ).toLowerCase(),
    path.normalize(
      path.resolve("C:\\Vekt\\vekt", "private", "uploads"),
    ).toLowerCase(),
  ];

  for (const filePath of uniquePaths) {
    const normalized = path.normalize(filePath).toLowerCase();

    const isAllowed = allowedUploadRoots.some(
      (root) =>
        normalized === root ||
        normalized.startsWith(`${root}${path.sep}`),
    );

    if (!isAllowed) continue;

    try {
      await unlink(filePath);
      logger.info({ filePath }, "Candidate resume deleted");
      return;
    } catch {
      // Resume may already be absent.
    }
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await auth();

  if (!session) {
    return NextResponse.json(
      { error: "Unauthorized" },
      { status: 401 },
    );
  }

  const role = (session.user as { role?: string }).role;

  if (role !== "ADMIN" && role !== "RECRUITER") {
    return NextResponse.json(
      { error: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;

  const candidate = await prisma.candidate.findUnique({
    where: { id },
    select: {
      id: true,
      resumePath: true,
      job: {
        select: {
          createdById: true,
        },
      },
    },
  });

  if (!candidate) {
    return NextResponse.json(
      { error: "Candidate not found" },
      { status: 404 },
    );
  }

  if (
    role !== "ADMIN" &&
    candidate.job?.createdById &&
    candidate.job.createdById !== session.user?.id
  ) {
    return NextResponse.json(
      { error: "Forbidden" },
      { status: 403 },
    );
  }

  await prisma.$transaction(async (tx) => {
    await tx.emailLog.deleteMany({
      where: { candidateId: id },
    });

    await tx.candidateAnswer.deleteMany({
      where: { candidateId: id },
    });

    await tx.evaluation.deleteMany({
      where: { candidateId: id },
    });

    await tx.candidate.delete({
      where: { id },
    });
  });

  await removeResumeFile(candidate.resumePath);

  logger.info(
    {
      candidateId: id,
      deletedBy: session.user?.id,
    },
    "Candidate permanently deleted",
  );

  return NextResponse.json({ ok: true });
}