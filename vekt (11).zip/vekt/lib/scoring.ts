﻿export type CriterionMatchType =
  | "DIRECT"
  | "TRANSFERABLE"
  | "EMERGING"
  | "ADJACENT"
  | "NO_EVIDENCE";

export type ScoringCriterion = {
  id: string;
  label: string;
  weight: number;
};

export type CriterionScore = {
  score: number;
  evidence: string;
};

export type CriterionScores = Record<string, CriterionScore>;

export const DEFAULT_SCORING_PROFILE: ScoringCriterion[] = [
  {
    id: "core_experience",
    label: "Core role experience & relevance",
    weight: 25,
  },
  {
    id: "portfolio",
    label: "Portfolio / demonstrated work",
    weight: 20,
  },
  {
    id: "tools",
    label: "Required tools & technical skills",
    weight: 15,
  },
  {
    id: "domain_knowledge",
    label: "Domain knowledge",
    weight: 15,
  },
  {
    id: "problem_solving",
    label: "Problem solving & ownership",
    weight: 10,
  },
  {
    id: "communication",
    label: "Communication & collaboration",
    weight: 10,
  },
  {
    id: "bonus",
    label: "Preferred / bonus skills",
    weight: 5,
  },
];

export function validateScoringProfile(
  profile: ScoringCriterion[],
): void {
  if (!Array.isArray(profile) || profile.length === 0) {
    throw new Error("Scoring profile must contain at least one criterion.");
  }

  const ids = new Set<string>();

  for (const criterion of profile) {
    if (!criterion.id || !criterion.label) {
      throw new Error("Every scoring criterion must have an id and label.");
    }

    if (ids.has(criterion.id)) {
      throw new Error(`Duplicate scoring criterion: ${criterion.id}`);
    }

    ids.add(criterion.id);

    if (
      !Number.isFinite(criterion.weight) ||
      criterion.weight < 0 ||
      criterion.weight > 100
    ) {
      throw new Error(
        `Invalid weight for ${criterion.id}. Weight must be between 0 and 100.`,
      );
    }
  }

  const total = profile.reduce(
    (sum, criterion) => sum + criterion.weight,
    0,
  );

  if (Math.abs(total - 100) > 0.001) {
    throw new Error(
      `Scoring weights must total 100. Current total: ${total}.`,
    );
  }
}

function clampScore(score: number): number {
  if (!Number.isFinite(score)) return 0;

  return Math.max(0, Math.min(100, score));
}

export function calculateWeightedScore(
  profile: ScoringCriterion[],
  scores: CriterionScores,
): number {
  validateScoringProfile(profile);

  const weightedTotal = profile.reduce((total, criterion) => {
    const criterionScore = scores[criterion.id]?.score ?? 0;
    const boundedScore = clampScore(criterionScore);

    return total + boundedScore * (criterion.weight / 100);
  }, 0);

  return Math.round(
    Math.max(0, Math.min(100, weightedTotal)),
  );
}

export function parseScoringProfile(
  stored: string | null | undefined,
): ScoringCriterion[] {
  if (!stored) {
    return DEFAULT_SCORING_PROFILE;
  }

  try {
    const parsed = JSON.parse(stored);

    if (!Array.isArray(parsed)) {
      return DEFAULT_SCORING_PROFILE;
    }

    validateScoringProfile(parsed);

    return parsed;
  } catch {
    return DEFAULT_SCORING_PROFILE;
  }
}

export function serializeScoringProfile(
  profile: ScoringCriterion[],
): string {
  validateScoringProfile(profile);
  return JSON.stringify(profile);
}
