$ErrorActionPreference = "Stop"

Set-Location "C:\Vekt\vekt"

Write-Host ""
Write-Host "=========================================="
Write-Host "VEKT FINAL AI EVALUATION FIX"
Write-Host "=========================================="

$path = (Resolve-Path ".\lib\ai.ts").Path
$backupDir = "C:\Vekt\vekt-backup-final-ai-fix"

New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
Copy-Item -Path $path -Destination (Join-Path $backupDir "ai.ts") -Force

Write-Host "Backup:"
Write-Host (Join-Path $backupDir "ai.ts")

$text = [System.IO.File]::ReadAllText($path)

$ollamaPattern = '(?s)model:\s*ollamaModel,\s*format:\s*"json",\s*stream:\s*false,\s*keep_alive:\s*"30m",\s*messages:\s*\['

$ollamaReplacement = @'
model: ollamaModel,
      format: "json",
      stream: false,
      keep_alive: "30m",
      options: {
        temperature: 0,
        top_p: 0.8,
        repeat_penalty: 1.2,
        num_predict: 900,
        num_ctx: 8192,
      },
      messages: [
'@

if (-not $text.Contains("repeat_penalty: 1.2")) {
    $changed = [regex]::Replace($text, $ollamaPattern, $ollamaReplacement, 1)
    if ($changed -eq $text) {
        throw "Could not locate the actual Ollama request block in lib/ai.ts. No changes were written."
    }
    $text = $changed
    Write-Host "Ollama generation controls inserted."
}

$rulesMarker = "VEKT_RECRUITER_SCORING_RULES_FINAL"

if (-not $text.Contains($rulesMarker)) {
    $rules = @'
VEKT_RECRUITER_SCORING_RULES_FINAL

Evaluate every criterion independently against the entire candidate resume.

GROUNDING:
Evidence must exist in the resume. Never invent facts, skills, duties, years,
outcomes, qualifications, or employment history. Never convert job requirements
into candidate facts.

RELEVANCE:
Evidence must materially support THIS criterion for THIS job. A matching
keyword alone is not evidence. Treat evidence as DIRECT, TRANSFERABLE, EMERGING,
ADJACENT, or NONE. ADJACENT does not count.

CAREER SWITCHERS:
Do not require the target job title. Give meaningful TRANSFERABLE credit when
actual responsibilities map to the target role. Do not describe transfer work
as professional employment in the target role.

FRESHERS:
Projects, internships, coursework, certifications, portfolios, volunteer work,
and other demonstrated work can provide meaningful evidence. Do not force zero
scores only because professional experience is limited.

UX/UI:
For UX/UI jobs, relevant evidence includes user research, interviews, workflow
analysis, information architecture, wireframing, prototyping, interaction
design, usability testing, accessibility, design iteration, and outcomes.
Do not infer UX/UI experience merely from AI, data science, programming,
analytics, software engineering, or generic technology work.

PORTFOLIO:
Search the whole resume for case studies, portfolio projects, UX/UI projects,
design process, wireframes, prototypes, testing, iterations, and outcomes.
Explicit relevant project/portfolio evidence is not "No evidence."

TOOLS:
Use explicit evidence of required tools and technical skills. Do not infer a
tool merely from job title or industry.

DOMAIN:
Assess actual understanding of users, user needs, workflows, usability,
accessibility, research findings, design decisions, and the job's problem
space. A generic tools list is not domain knowledge.

PROBLEM SOLVING:
Reward identifying a problem, investigation, analysis, solution, testing,
measurement, iteration, or ownership.

COMMUNICATION:
Reward explicit presentations, stakeholder communication, cross-functional work,
requirements, documentation, mentoring, workshops, or communicating findings.

BONUS:
Award bonus only when the resume explicitly supports the preferred skill.

CRITERION INDEPENDENCE:
Do not blindly reuse one evidence sentence across unrelated criteria. The same
passage may support multiple criteria only when it genuinely supports each.

ZERO:
Use 0 + "No evidence in resume." only after reviewing the entire resume and
finding no meaningful relevant evidence for that criterion.

SCORE GUIDANCE:
90-100 extensive highly relevant direct evidence
70-89 strong relevant evidence
50-69 meaningful direct, transferable, or emerging evidence with gaps
30-49 limited but meaningful evidence or partial transfer
1-29 very weak relevant evidence
0 no meaningful relevant evidence

Keep each evidence string concise and grounded in the resume. Return ONLY the
required JSON structure. Do not add commentary outside JSON.
END_VEKT_RECRUITER_SCORING_RULES_FINAL

'@

    $systemIndex = $text.IndexOf("const SYSTEM_PROMPT")
    if ($systemIndex -lt 0) { $systemIndex = $text.IndexOf("SYSTEM_PROMPT =") }
    if ($systemIndex -lt 0) { throw "Could not find SYSTEM_PROMPT in lib/ai.ts." }

    $templateStart = $text.IndexOf("`", $systemIndex)
    if ($templateStart -lt 0) { throw "Could not find SYSTEM_PROMPT template literal in lib/ai.ts." }

    $insertAt = $templateStart + 1
    $text = $text.Substring(0, $insertAt) + "`r`n" + $rules + $text.Substring($insertAt)
    Write-Host "Compact recruiter scoring rules inserted."
}

$text = $text.Replace("2026.09.8", "2026.10.01")
$text = $text.Replace("2026.09.9", "2026.10.01")
$text = $text.Replace("2026.09.10", "2026.10.01")

[System.IO.File]::WriteAllText($path, $text, [System.Text.UTF8Encoding]::new($false))

$verify = [System.IO.File]::ReadAllText($path)
$required = @(
    "VEKT_RECRUITER_SCORING_RULES_FINAL",
    "CAREER SWITCHERS:",
    "FRESHERS:",
    "PORTFOLIO:",
    "CRITERION INDEPENDENCE:",
    "model: ollamaModel",
    'keep_alive: "30m"',
    "options:",
    "temperature: 0",
    "top_p: 0.8",
    "repeat_penalty: 1.2",
    "num_predict: 900",
    "num_ctx: 8192"
)

$missing = @()
foreach ($item in $required) {
    if (-not $verify.Contains($item)) { $missing += $item }
}

if ($missing.Count -gt 0) {
    Write-Host ""
    Write-Host "PATCH FAILED"
    $missing | ForEach-Object { Write-Host "MISSING: $_" }
    throw "Verification failed. Build was NOT started."
}

Write-Host ""
Write-Host "=========================================="
Write-Host "PATCH VERIFIED"
Write-Host "=========================================="
Write-Host "Scoring rules: OK"
Write-Host "Ollama generation controls: OK"
Write-Host ""
Write-Host "Running production build..."

pnpm run build
if ($LASTEXITCODE -ne 0) { throw "Production build failed." }

Write-Host ""
Write-Host "BUILD SUCCESSFUL"

New-Item -ItemType Directory -Force -Path ".\.next\standalone\.next" | Out-Null
Copy-Item -Path ".next\static" -Destination ".next\standalone\.next\static" -Recurse -Force
Copy-Item -Path "public" -Destination ".next\standalone\public" -Recurse -Force

Write-Host "Standalone static/public assets refreshed."
Write-Host ""
Write-Host "=========================================="
Write-Host "FINAL FIX COMPLETE"
Write-Host "=========================================="
Write-Host "Backup: $backupDir\ai.ts"
Write-Host ""
Write-Host "Start Vekt with:"
Write-Host '$env:DATABASE_URL="file:C:/Vekt/vekt/dev.db"'
Write-Host '$env:HOSTNAME="127.0.0.1"'
Write-Host 'node .next/standalone/server.js'
