﻿"use client";

import { useState } from "react";

type Job = { id: string; title: string };
type Source =
  | "EMAIL" | "LINKEDIN" | "PEOPLEHUM" | "WHATSAPP"
  | "REFERRAL" | "JOB_PORTAL" | "WEBSITE" | "OTHER";

const SOURCES: { value: Source; label: string }[] = [
  { value: "EMAIL", label: "Email" },
  { value: "LINKEDIN", label: "LinkedIn" },
  { value: "PEOPLEHUM", label: "PeopleHum" },
  { value: "WHATSAPP", label: "WhatsApp" },
  { value: "REFERRAL", label: "Referral" },
  { value: "JOB_PORTAL", label: "Job Portal" },
  { value: "WEBSITE", label: "Website" },
  { value: "OTHER", label: "Other" },
];

export default function BulkUploadForm({ jobs }: { jobs: Job[] }) {
  const [jobId, setJobId] = useState("");
  const [source, setSource] = useState<Source>("EMAIL");
  const [files, setFiles] = useState<File[]>([]);
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<{ file: string; ok: boolean; message: string }[]>([]);

  async function startUpload() {
    if (!jobId || files.length === 0 || running) return;
    setRunning(true);
    setResults([]);

    for (const file of files) {
      if (file.type !== "application/pdf") {
        setResults((r) => [...r, { file: file.name, ok: false, message: "PDF only" }]);
        continue;
      }

      try {
        const form = new FormData();
        form.append("resume", file);
        form.append("jobId", jobId);
        form.append("source", source);

        const response = await fetch("/api/recruiter/bulk-candidates", {
          method: "POST",
          body: form,
        });
        const data = await response.json();

        setResults((r) => [
          ...r,
          response.ok
            ? { file: file.name, ok: true, message: `Imported â€” AI score ${data.candidate?.evaluation?.score ?? "pending"}` }
            : { file: file.name, ok: false, message: data.error ?? "Import failed" },
        ]);
      } catch {
        setResults((r) => [...r, { file: file.name, ok: false, message: "Network error" }]);
      }
    }

    setRunning(false);
  }

  const done = results.length;
  const success = results.filter((r) => r.ok).length;

  return (
    <div className="rounded-xl border bg-card p-5 space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="text-sm font-medium">
          Job
          <select
            className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm"
            value={jobId}
            onChange={(e) => setJobId(e.target.value)}
            disabled={running}
          >
            <option value="">Select a job</option>
            {jobs.map((job) => <option key={job.id} value={job.id}>{job.title}</option>)}
          </select>
        </label>

        <label className="text-sm font-medium">
          Candidate source
          <select
            className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm"
            value={source}
            onChange={(e) => setSource(e.target.value as Source)}
            disabled={running}
          >
            {SOURCES.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
          </select>
        </label>
      </div>

      <label className="block text-sm font-medium">
        Resume PDFs
        <input
          className="mt-1.5 block w-full rounded-md border bg-background px-3 py-2 text-sm"
          type="file"
          accept="application/pdf,.pdf"
          multiple
          onChange={(e) => {
            setFiles(Array.from(e.target.files ?? []));
            setResults([]);
          }}
          disabled={running}
        />
      </label>

      <div className="flex items-center justify-between gap-4">
        <p className="text-xs text-muted-foreground">
          {running ? `Processing ${done} / ${files.length}â€¦` : `${files.length} file(s) selected${done ? ` Â· ${success} imported` : ""}`}
        </p>
        <button
          type="button"
          onClick={startUpload}
          disabled={running || !jobId || files.length === 0}
          className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
        >
          {running ? "Processingâ€¦" : "Start bulk upload"}
        </button>
      </div>

      {results.length > 0 && (
        <div className="space-y-2 border-t pt-4">
          {results.map((r, i) => (
            <div key={`${r.file}-${i}`} className="flex justify-between gap-4 rounded-md border px-3 py-2 text-sm">
              <span className="truncate">{r.file}</span>
              <span className={r.ok ? "text-green-600" : "text-destructive"}>{r.message}</span>
            </div>
          ))}
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        If a PDF does not contain a detectable email address, Vekt skips it so you can add that candidate manually.
        Bulk-imported candidates do not have consent asserted automatically.
      </p>
    </div>
  );
}
