import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { DEFAULT_SCORING_PROFILE, parseScoringProfile } from "@/lib/scoring";
import { notFound, redirect } from "next/navigation";
import ScoringProfileEditor from "./ScoringProfileEditor";

export default async function ScoringProfilePage({
  params,
}: {
  params: Promise<{ jobId: string }>;
}) {
  const session = await auth();

  if (!session) {
    redirect("/login");
  }

  const isAdmin =
    (session.user as { role?: string }).role === "ADMIN";

  const currentUserId = session.user?.id;

  if (!isAdmin && !currentUserId) {
    redirect("/login");
  }

  const { jobId } = await params;

  const job = await prisma.job.findFirst({
    where: {
      id: jobId,
      ...(!isAdmin && currentUserId
        ? { createdById: currentUserId }
        : {}),
    },
    select: {
      id: true,
      title: true,
      scoringProfile: true,
    },
  });

  if (!job) {
    notFound();
  }

  let profile = DEFAULT_SCORING_PROFILE;

  try {
    profile = parseScoringProfile(job.scoringProfile);
  } catch {
    profile = DEFAULT_SCORING_PROFILE;
  }

  return (
    <ScoringProfileEditor
      jobId={job.id}
      jobTitle={job.title}
      initialProfile={profile}
    />
  );
}