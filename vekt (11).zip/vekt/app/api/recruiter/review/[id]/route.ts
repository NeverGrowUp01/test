import {
  CandidateStatus,
  EmailType,
} from "@/generated/client";
import { auth } from "@/lib/auth";
import { sendCandidateEmail } from "@/lib/email";
import { prisma } from "@/lib/prisma";
import { reviewDecisionSchema } from "@/lib/schemas";
import { NextResponse } from "next/server";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function PATCH(
  req: Request,
  { params }: RouteContext,
) {
  try {
    const session = await auth();

    if (!session) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 },
      );
    }

    const isAdmin =
      (session.user as { role?: string }).role === "ADMIN";

    const currentUserId = session.user?.id;

    if (!isAdmin && !currentUserId) {
      return NextResponse.json(
        {
          error:
            "Session is stale. Please sign in again.",
        },
        { status: 401 },
      );
    }

    const { id } = await params;
    const body = await req.json();

    const parsed =
      reviewDecisionSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        {
          error: "Invalid review decision.",
        },
        { status: 400 },
      );
    }

    const { decision } = parsed.data;

    const candidate =
      await prisma.candidate.findUnique({
        where: { id },
        include: {
          job: {
            select: {
              id: true,
              title: true,
              createdById: true,
            },
          },
        },
      });

    if (!candidate) {
      return NextResponse.json(
        {
          error: "Candidate not found.",
        },
        { status: 404 },
      );
    }

    if (
      !isAdmin &&
      candidate.job?.createdById !== currentUserId
    ) {
      return NextResponse.json(
        {
          error:
            "You are not allowed to review this candidate.",
        },
        { status: 403 },
      );
    }

    let newStatus: CandidateStatus;
    let emailType: EmailType;

    switch (decision) {
      case "SHORTLIST":
        newStatus = CandidateStatus.SHORTLISTED;
        emailType = EmailType.SHORTLISTED;
        break;

      case "REJECT":
        newStatus = CandidateStatus.REJECTED;
        emailType = EmailType.REJECTED;
        break;

      case "ACCEPT":
        newStatus = CandidateStatus.ACCEPTED;
        emailType = EmailType.ACCEPTED;
        break;

      default:
        return NextResponse.json(
          {
            error: "Unsupported review decision.",
          },
          { status: 400 },
        );
    }

    const updated =
      await prisma.candidate.update({
        where: { id: candidate.id },
        data: {
          status: newStatus,
        },
        select: {
          id: true,
          name: true,
          email: true,
          status: true,
          updatedAt: true,
        },
      });

    let emailSent = false;
    let emailError: string | null = null;

    try {
      await sendCandidateEmail({
        candidateId: candidate.id,
        type: emailType,
      });

      emailSent = true;
    } catch (error) {
      emailError =
        error instanceof Error
          ? error.message
          : "Email delivery failed.";
    }

    return NextResponse.json({
      ok: true,
      candidate: updated,
      emailSent,
      ...(emailError
        ? { emailError }
        : {}),
    });
  } catch (error) {
    console.error(
      "Recruiter review update failed:",
      error,
    );

    return NextResponse.json(
      {
        error:
          "Could not update candidate review status.",
      },
      { status: 500 },
    );
  }
}