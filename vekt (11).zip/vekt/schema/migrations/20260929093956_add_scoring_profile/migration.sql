-- AlterTable
ALTER TABLE "Job" ADD COLUMN "scoringProfile" TEXT;

-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Evaluation" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "score" INTEGER NOT NULL,
    "reasoning" TEXT NOT NULL,
    "pros" TEXT NOT NULL,
    "cons" TEXT NOT NULL,
    "criteriaScores" TEXT NOT NULL DEFAULT '{}',
    "promptSnapshot" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "candidateId" TEXT NOT NULL,
    "provider" TEXT NOT NULL DEFAULT 'unknown',
    "model" TEXT NOT NULL DEFAULT 'unknown',
    "promptHash" TEXT NOT NULL DEFAULT '',
    "evaluatorVersion" TEXT NOT NULL DEFAULT '',
    "redactions" TEXT NOT NULL DEFAULT '{}',
    "autoDecision" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "Evaluation_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES "Candidate" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Evaluation" ("autoDecision", "candidateId", "cons", "createdAt", "evaluatorVersion", "id", "model", "promptHash", "promptSnapshot", "pros", "provider", "reasoning", "redactions", "score") SELECT "autoDecision", "candidateId", "cons", "createdAt", "evaluatorVersion", "id", "model", "promptHash", "promptSnapshot", "pros", "provider", "reasoning", "redactions", "score" FROM "Evaluation";
DROP TABLE "Evaluation";
ALTER TABLE "new_Evaluation" RENAME TO "Evaluation";
CREATE UNIQUE INDEX "Evaluation_candidateId_key" ON "Evaluation"("candidateId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
