﻿import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import * as XLSX from "xlsx";
import { NextResponse } from "next/server";

export async function GET() {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const isAdmin = (session.user as { role?: string }).role === "ADMIN";
  const currentUserId = session.user?.id;
  if (!isAdmin && !currentUserId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const candidates = await prisma.candidate.findMany({
    where: !isAdmin && currentUserId
      ? { job: { is: { createdById: currentUserId } } }
      : undefined,
    orderBy: { appliedAt: "desc" },
    include: {
      job: { select: { title: true } },
      evaluation: {
        select: {
          score: true,
          reasoning: true,
          pros: true,
          cons: true,
          provider: true,
          model: true,
          createdAt: true,
        },
      },
    },
  });

  const rows = candidates.map((c) => ({
    "Candidate Name": c.name,
    "Email": c.email,
    "Job": c.job?.title ?? "",
    "Source": c.source,
    "Application Date": c.appliedAt.toISOString(),
    "AI Score": c.evaluation?.score ?? "",
    "AI Summary": c.evaluation?.reasoning ?? "",
    "Pros": c.evaluation?.pros ?? "",
    "Cons": c.evaluation?.cons ?? "",
    "Candidate Status": c.status,
    "AI Provider": c.evaluation?.provider ?? "",
    "AI Model": c.evaluation?.model ?? "",
    "Evaluation Date": c.evaluation?.createdAt?.toISOString() ?? "",
    "Resume Filename": c.resumePath.split("/").pop() ?? "",
  }));

  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(workbook, worksheet, "Candidates");

  const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="vekt-candidates-${new Date().toISOString().slice(0, 10)}.xlsx"`,
      "Cache-Control": "no-store",
    },
  });
}
