import { serve } from "inngest/next";
import {
  analyzeCandidate,
  purgeExpiredCandidates,
} from "@/lib/queue";
import { inngest } from "@/lib/inngest";

export const { GET, POST, PUT } = serve({
  client: inngest,
  functions: [
    analyzeCandidate,
    purgeExpiredCandidates,
  ],
});